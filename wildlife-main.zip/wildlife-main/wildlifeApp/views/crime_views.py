import requests
import os
import json
from django.http import JsonResponse
from django.views import View

class FetchWildlifeCrimeData(View):
    def get(self, request):
        deepseek_url = "https://api.deepseek.com/chat/completions"
        API_KEY = os.getenv("API_KEY")  # Load DeepSeek API key from environment
        OPENCAGE_API_KEY = os.getenv("OPENCAGE_API_KEY")  # Load OpenCage API key from environment
        print("OpenCage API Key:", OPENCAGE_API_KEY)
        headers = {
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": "deepseek-chat",
            "messages": [
                {
                    "role": "user",
                    "content": (
                       "Generate a dataset of 5 wildlife crime incidents in valid JSON array format. "
    "Each entry must have: crime_type (string), species (string), "
    "location (string), incidents (number), arrests (number), date (YYYY-MM-DD). "
    "Return ONLY the raw JSON array without any formatting, comments, or markdown."
                    )
                }
            ],
            "max_tokens": 500
        }

        try:
            # Step 1: Fetch wildlife crime data from DeepSeek API
            response = requests.post(deepseek_url, headers=headers, json=payload)
            response.raise_for_status()  # Raise an exception for HTTP errors
            print("DeepSeek API raw response:", response.text)  # For debugging

            data = response.json()
            if "choices" not in data or not data["choices"]:
                return JsonResponse({"error": "Unexpected API response format"}, status=500)

            content = data["choices"][0]["message"]["content"]

            # Step 2: Parse the JSON data from the content
            wildlife_crime_data = json.loads(content)

            # Step 3: Geocode locations to get latitude and longitude
            for entry in wildlife_crime_data:
                location = entry.get("location")
                if location:
                    entry["latitude"], entry["longitude"] = self.geocode_location(location, OPENCAGE_API_KEY)

            return JsonResponse(wildlife_crime_data, safe=False)
        except requests.exceptions.RequestException as e:
            return JsonResponse({"error": str(e)}, status=500)
        except json.JSONDecodeError as e:
            return JsonResponse({"error": "Invalid JSON response from DeepSeek API"}, status=500)
        except Exception as e:
            return JsonResponse({"error": f"An error occurred: {str(e)}"}, status=500)

    def geocode_location(self, location, api_key):
        """
        Geocode a location using OpenCage Geocoder.
        Returns (latitude, longitude) or (None, None) if geocoding fails.
        """
        geocode_url = "https://api.opencagedata.com/geocode/v1/json"
        params = {
            "q": location,
            "key": api_key,
        }

        try:
            response = requests.get(geocode_url, params=params)
            response.raise_for_status()
            data = response.json()

            if data.get("results"):
                latitude = data["results"][0]["geometry"]["lat"]
                longitude = data["results"][0]["geometry"]["lng"]
                return latitude, longitude
            else:
                print(f"Geocoding failed for location: {location}")
                return None, None
        except requests.exceptions.RequestException as e:
            print(f"Geocoding request failed for location: {location}. Error: {e}")
            return None, None