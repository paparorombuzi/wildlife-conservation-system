# chat.py
import requests
import os
import json
from django.http import JsonResponse
from django.views import View
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from wildlifeApp.models import ChatMessage

class AIChat(View):
    @method_decorator(csrf_exempt)
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)

    # Update the post method in AIChat view
    def post(self, request):
        try:
            data = json.loads(request.body)
            user_message = data.get('message', '')
            
            # Handle session for anonymous users
            if not request.user.is_authenticated:
                if not request.session.session_key:
                    request.session.create()
                session_key = request.session.session_key
            else:
                session_key = ''

            # Create user message
            ChatMessage.objects.create(
                user=request.user if request.user.is_authenticated else None,
                content=user_message,
                is_user=True,
                session_key=session_key
            )
            
            # Create message for either authenticated user or anonymous session
            ChatMessage.objects.create(
                user=request.user if request.user.is_authenticated else None,
                content=user_message,
                is_user=True,
                session_key=request.session.session_key if not request.user.is_authenticated else ''
            )
            API_KEY = os.getenv("API_KEY") 
            # API call to Deepseek
            headers = {
                "Content-Type": "application/json",
                "Authorization":  f"Bearer {API_KEY}"
            }
            
            payload = {
                "model": "deepseek-chat",
                "messages": [{"role": "user", "content": user_message}]
            }

            response = requests.post(
                "https://api.deepseek.com/chat/completions",
                headers=headers,
                json=payload
            )
            response.raise_for_status()

            bot_response = response.json()['choices'][0]['message']['content']

            # Save bot response
            ChatMessage.objects.create(
                user=request.user if request.user.is_authenticated else None,
                content=bot_response,
                is_user=False,
                session_key=request.session.session_key if not request.user.is_authenticated else ''
            )

            return JsonResponse({'response': bot_response})

        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)

    def get(self, request):
        # Get messages for authenticated users or anonymous sessions
        if request.user.is_authenticated:
            messages = ChatMessage.objects.filter(user=request.user)
        else:
            if not request.session.session_key:
                request.session.create()
            messages = ChatMessage.objects.filter(session_key=request.session.session_key)

        return JsonResponse({
            'messages': [
                {
                    'id': msg.id,
                    'text': msg.content,
                    'isUser': msg.is_user,
                    'timestamp': msg.timestamp.isoformat(),
                    'isOwn': msg.session_key == request.session.session_key or msg.user == request.user
                }
                for msg in messages.order_by('timestamp')
            ]
        })