import requests
from django.http import JsonResponse
import os
from django.views import View
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt

def get_climate_data(request):
    API_KEY = os.getenv("OPENWEATHERMAP_API_KEY", "9ae7ae5b44111ec0ef9513ab9ba2aebf")
    CITY = "Nairobi"
    URL = f"http://api.openweathermap.org/data/2.5/forecast?q={CITY}&appid={API_KEY}&units=metric"

    response = requests.get(URL)
    if response.status_code == 200:
        data = response.json()
        return JsonResponse(data)
    else:
        return JsonResponse({"error": "Failed to fetch data"}, status=response.status_code)

@method_decorator(csrf_exempt, name='dispatch')
class FetchClimateData(View):
    API_KEY = os.getenv("OPENWEATHERMAP_API_KEY", "9ae7ae5b44111ec0ef9513ab9ba2aebf")
    CITY = "Nairobi"
    URL = f"http://api.openweathermap.org/data/2.5/forecast?q={CITY}&appid={API_KEY}&units=metric"

    def get(self, request, *args, **kwargs):
        response = requests.get(self.URL)
        if response.status_code == 200:
            data = response.json()
            return JsonResponse(data["list"], safe=False)  # Contains 5-day forecast data
        else:
            return JsonResponse({"error": "Failed to fetch data"}, status=response.status_code)