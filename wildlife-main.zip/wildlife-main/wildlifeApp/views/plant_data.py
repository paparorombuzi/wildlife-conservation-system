import requests
import os
import json
import re  # For Markdown JSON extraction
from django.http import JsonResponse
from django.views import View

class FetchPlantData(View):
    def get(self, request):
        deepseek_url = "https://api.deepseek.com/chat/completions"
        API_KEY = os.getenv("API_KEY")  # Ensure this is set in your environment
        headers = {
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": "deepseek-chat",
            "messages": [
                {
                    "role": "user",
                    "content": (
                        "Generate a dataset of 5 plant species in JSON format with the following fields: "
                        "name, scientific_name, status (e.g., Endangered, Vulnerable), biodiversity_index, "
                        "location, latitude, and longitude. Ensure that latitude and longitude values correspond "
                        "accurately to the given location. Return only the JSON data without any markdown formatting."
                    )
                }
            ],
            "max_tokens": 500
        }

        try:
            # Fetch data (disable SSL verify if needed)
            response = requests.post(
                deepseek_url,
                headers=headers,
                json=payload,
                verify=False  # Only for testing! Remove in production.
            )
            response.raise_for_status()  # Raises HTTPError for bad responses
            data = response.json()

            # Validate API response structure
            if not data.get("choices") or not isinstance(data["choices"], list):
                return JsonResponse({"error": "Invalid API response format: 'choices' missing"}, status=500)

            content = data["choices"][0]["message"].get("content", "")
            if not content:
                return JsonResponse({"error": "Empty content in API response"}, status=500)

            # Extract JSON from Markdown (if present)
            json_match = re.search(r'```json\n([\s\S]*?)\n```', content)
            if json_match:
                content = json_match.group(1)

            # Parse JSON safely
            plant_data = json.loads(content)
            return JsonResponse(plant_data, safe=False)

        except requests.exceptions.RequestException as e:
            return JsonResponse({"error": f"API request failed: {str(e)}"}, status=500)
        except json.JSONDecodeError as e:
            return JsonResponse({"error": f"Invalid JSON: {str(e)}"}, status=500)
        except Exception as e:
            return JsonResponse({"error": f"Unexpected error: {str(e)}"}, status=500)