import requests
from django.http import JsonResponse

def get_deforestation_data(request):
    API_KEY = "a2c542131bf51d012adf41d83ccf820f"  # Replace with your NASA FIRMS API key

    # Define the bounding box [west, south, east, north]
    # Example: Kenya bounding box
    bounding_box = [33.83, -4.73, 41.91, 5.62]

    # Construct the URL with the bounding box
    url = f"https://firms.modaps.eosdis.nasa.gov/api/area/csv/{API_KEY}/VIIRS_SNPP_NRT/{','.join(map(str, bounding_box))}/5"

    response = requests.get(url)

    if response.status_code == 200:
        return JsonResponse({"data": response.text})
    else:
        return JsonResponse({"error": response.text}, status=response.status_code)

def get_forest_change(request):
    API_KEY = "your_gfw_API_KEY"  # Replace with a valid API key
    GEO_ID = "your_geostore_id"  # Replace with a valid geostore ID

    API_URL = f"https://api.globalforestwatch.org/v1/loss?geostore_id={GEO_ID}"

    headers = {"Authorization": f"Bearer {API_KEY}"}
    response = requests.get(API_URL, headers=headers)

    if response.status_code == 200:
        return JsonResponse(response.json())
    else:
        return JsonResponse({"error": response.text}, status=response.status_code)
