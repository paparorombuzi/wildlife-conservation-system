from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from django.contrib.auth.models import User
from wildlifeApp.views.serializers import RegisterSerializer, EmailLoginSerializer
from wildlifeApp.views.otp_utils import send_otp
from rest_framework.authtoken.models import Token

class SendOTPView(generics.GenericAPIView):
    """Sends OTP to email"""
    def post(self, request):
        email = request.data.get('email')
        send_otp(email)
        return Response({'detail': 'OTP sent'})

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer


class LoginView(generics.GenericAPIView):
    serializer_class = EmailLoginSerializer
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        user = serializer.validated_data['user']
        token, created = Token.objects.get_or_create(user=user)
        
        return Response({
            'token': token.key,
            'email': user.email,
            'first_name': user.first_name,
            'last_name': user.last_name
        })