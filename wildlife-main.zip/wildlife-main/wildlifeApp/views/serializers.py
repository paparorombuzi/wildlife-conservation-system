from rest_framework import serializers
from django.contrib.auth.models import User
from .otp_utils import verify_otp
from rest_framework import serializers
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from rest_framework.exceptions import AuthenticationFailed


class RegisterSerializer(serializers.ModelSerializer):
    otp = serializers.CharField(write_only=True)
    first_name = serializers.CharField(write_only=True)
    last_name = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ('email', 'password', 'otp', 'first_name', 'last_name')
        extra_kwargs = {'password': {'write_only': True}}

    def validate(self, attrs):
        email = attrs.get('email')
        otp = attrs.pop('otp')
        if not verify_otp(email, otp):
            raise serializers.ValidationError("Invalid OTP")
        return attrs

    def create(self, validated_data):
        return User.objects.create_user(
            username=validated_data['email'],
            email=validated_data['email'],
            password=validated_data['password'],
            first_name=validated_data['first_name'],
            last_name=validated_data['last_name'],
        )


class EmailLoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)

    def validate(self, attrs):
        email = attrs.get('email')
        password = attrs.get('password')

        # Find user by email
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            raise AuthenticationFailed('Invalid credentials')

        # Authenticate with username (since Django auth uses username)
        authenticated_user = authenticate(username=user.username, password=password)
        if not authenticated_user:
            raise AuthenticationFailed('Invalid credentials')

        if not authenticated_user.is_active:
            raise AuthenticationFailed('User account is disabled')

        return {
            'user': authenticated_user,
            'email': authenticated_user.email,
            'username': authenticated_user.username
        }