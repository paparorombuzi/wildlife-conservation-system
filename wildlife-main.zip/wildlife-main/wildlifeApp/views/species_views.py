import requests
import os
import json
from django.http import JsonResponse
from django.views import View

class FetchSpeciesData(View):
    def get(self, request):
        deepseek_url = "https://api.deepseek.com/chat/completions"
        API_KEY = os.getenv("API_KEY")  # Load DeepSeek API key from environment
        OPENCAGE_API_KEY = os.getenv("OPENCAGE_API_KEY")  # Load OpenCage API key from environment

        headers = {
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": "deepseek-chat",
            "messages": [
                {
                    "role": "user",
                    "content": (
                       "Generate a valid JSON array containing exactly 8 wildlife species records. Each entry must include the following fields: species (string), population_trend (string, e.g., increasing, decreasing, stable), habitat_range (string, e.g., forest, desert, ocean), threats (array of strings, e.g., habitat loss, climate change, poaching), conservation_status (string, e.g., endangered, vulnerable, least concern), latitude (float), longitude (float), climate_impact (string, e.g., temperature rise, sea level rise), and predicted_population_change (string, e.g., +10%, -20%, stable). Return only the raw JSON array without any additional formatting, comments, or markdown."
                    )
                }
            ],
            "max_tokens": 900
        }

        try:
            # Step 1: Fetch species data from DeepSeek API
            response = requests.post(deepseek_url, headers=headers, json=payload, timeout=60)
            response.raise_for_status()  # Raise an exception for HTTP errors
            print("DeepSeek API response:", response.text)  # Debugging output

            # Step 2: Parse the JSON response
            data = response.json()
            if "choices" not in data or not data["choices"]:
                return JsonResponse({"error": "Unexpected API response format"}, status=500)

            content = data["choices"][0]["message"]["content"]
            try:
                species_data = json.loads(content)
            except json.JSONDecodeError:
                return JsonResponse({"error": "Invalid JSON from DeepSeek"}, status=500)

            # Step 3: Geocode habitat ranges (if not provided)
            for entry in species_data:
                if "latitude" not in entry or "longitude" not in entry:
                    habitat_range = entry.get("habitat_range")
                    if habitat_range:
                        entry["latitude"], entry["longitude"] = self.geocode_location(habitat_range, OPENCAGE_API_KEY)

            return JsonResponse(species_data, safe=False)

        except requests.exceptions.RequestException as e:
            print("Request Error:", e)
            return JsonResponse({"error": f"Request failed: {str(e)}"}, status=500)
        except Exception as e:
            print("Unexpected Error:", e)
            return JsonResponse({"error": f"An unexpected error occurred: {str(e)}"}, status=500)

    def geocode_location(self, location, api_key):
        """
        Geocode a location using OpenCage Geocoder.
        Returns (latitude, longitude) or (None, None) if geocoding fails.
        """
        geocode_url = "https://api.opencagedata.com/geocode/v1/json"
        params = {
            "q": location,
            "key": api_key,
        }

        try:
            response = requests.get(geocode_url, params=params)
            response.raise_for_status()
            data = response.json()

            if data.get("results"):
                latitude = data["results"][0]["geometry"]["lat"]
                longitude = data["results"][0]["geometry"]["lng"]
                return latitude, longitude
            else:
                print(f"Geocoding failed for location: {location}")
                return None, None
        except requests.exceptions.RequestException as e:
            print(f"Geocoding request failed for location: {location}. Error: {e}")
            return None, None