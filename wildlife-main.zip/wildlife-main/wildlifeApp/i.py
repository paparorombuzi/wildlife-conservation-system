# wildlife/views.py
from rest_framework import viewsets
from .models import WildlifeObservation, ClimateData
from .serializers import WildlifeObservationSerializer, ClimateDataSerializer
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .ml.predict import predict_temperature


def get_bird_migration(request):
    API_KEY = "your_ebird_API_KEY"
    url = f"https://api.ebird.org/v2/data/obs/Kenya/recent"
    
    headers = {"X-eBirdApiToken": API_KEY}
    response = requests.get(url, headers=headers)
    data = response.json()

    return JsonResponse(data)

import requests
from django.http import JsonResponse

def get_climate_data(request):
    API_KEY = "your_openweathermap_API_KEY"
    url = f"http://api.openweathermap.org/data/2.5/weather?q=Nairobi&appid={API_KEY}&units=metric"
    
    response = requests.get(url)
    data = response.json()

    return JsonResponse(data)

def get_deforestation_data(request):
    API_KEY = "your_nasa_firms_API_KEY"
    url = f"https://firms.modaps.eosdis.nasa.gov/api/area/csv/{API_KEY}/VIIRS_SNPP_NRT/world/1000/10"
    
    response = requests.get(url)
    data = response.text  # NASA FIRMS returns CSV

    return JsonResponse({"data": data})

def get_forest_change(request):
    API_URL = "https://api.globalforestwatch.org/v1/forest-change"
    
    response = requests.get(API_URL)
    data = response.json()

    return JsonResponse(data)

def get_species_data(request):
    API_URL = "https://api.gbif.org/v1/occurrence/search?country=KE"

    response = requests.get(API_URL)
    data = response.json()

    return JsonResponse(data)

def get_wildlife_crime(request):
    API_URL = "https://api.wwf.org/wildlife_crime"

    response = requests.get(API_URL)
    data = response.json()

    return JsonResponse(data)

