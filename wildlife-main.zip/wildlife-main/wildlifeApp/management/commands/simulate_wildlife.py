# wildlife/management/commands/simulate_wildlife.py
import random
from django.core.management.base import BaseCommand
from wildlifeApp.models import WildlifeObservation
from datetime import datetime

SPECIES = ['Elephant', 'Lion', 'Giraffe', 'Zebra']

class Command(BaseCommand):
    help = 'Simulate wildlife observations'

    def handle(self, *args, **options):
        observation = WildlifeObservation.objects.create(
            species=random.choice(SPECIES),
            location_lat=-1.0 + random.uniform(-0.5, 0.5),
            location_long=36.8 + random.uniform(-0.5, 0.5),
        )
        self.stdout.write(self.style.SUCCESS(f'Simulated observation: {observation}'))
