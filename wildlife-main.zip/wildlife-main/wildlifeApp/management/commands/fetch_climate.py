# wildlife/management/commands/fetch_climate.py
import requests
from django.core.management.base import BaseCommand
from wildlifeApp.models import ClimateData

class Command(BaseCommand):
    help = 'Fetch climate data from OpenWeatherMap API'

    def handle(self, *args, **options):
        API_KEY = "YOUR_OPENWEATHERMAP_API_KEY"
        city = "Nairobi"
        url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"
        response = requests.get(url)
        data = response.json()
        # Extract relevant data
        temperature = data['main']['temp']
        humidity = data['main']['humidity']

        ClimateData.objects.create(
            temperature=temperature,
            humidity=humidity,
            city=city
        )
        self.stdout.write(self.style.SUCCESS('Successfully fetched and stored climate data'))
