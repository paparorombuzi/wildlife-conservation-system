from datetime import datetime
from django.core.management.base import BaseCommand
import requests
from requests.auth import HTTPBasicAuth
from wildlifeApp.models import WildlifeMovement, ClimateData

class Command(BaseCommand):
    help = "Fetch and save data from external APIs"

    def handle(self, *args, **kwargs):
        # Fetch wildlife data from Movebank
        movebank_url = "https://www.movebank.org/movebank/service/direct-read?entity_type=event&study_id=903731448"
        response = requests.get(
            movebank_url,
            auth=HTTPBasicAuth('mutura', 'B9h!yqa*56B4vT!')
        )

        # Debug: Print status code and response content
        self.stdout.write(f"Movebank Response Status Code: {response.status_code}")
        self.stdout.write(f"Movebank Response Content: {response.text}")

        if response.status_code == 200:
            try:
                wildlife_data = response.json()
                # Save wildlife data
                for entry in wildlife_data:
                    WildlifeMovement.objects.create(
                        species=entry['species'],
                        latitude=entry['location-lat'],
                        longitude=entry['location-long'],
                        timestamp=datetime.strptime(entry['timestamp'], '%Y-%m-%dT%H:%M:%SZ')
                    )
                self.stdout.write(self.style.SUCCESS('Wildlife data fetched and saved successfully!'))
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'Error parsing wildlife data: {e}'))
        else:
            self.stdout.write(self.style.ERROR(f'Failed to fetch wildlife data. Status code: {response.status_code}'))

        # Fetch climate data from OpenWeatherMap
        openweathermap_url = "https://api.openweathermap.org/data/2.5/weather?q=Nairobi&appid=9ae7ae5b44111ec0ef9513ab9ba2aebf"
        response = requests.get(openweathermap_url)

        # Debug: Print status code and response content
        self.stdout.write(f"OpenWeatherMap Response Status Code: {response.status_code}")
        self.stdout.write(f"OpenWeatherMap Response Content: {response.text}")

        if response.status_code == 200:
            try:
                climate_data = response.json()
                # Save climate data
                ClimateData.objects.create(
                    temperature=climate_data['main']['temp'],
                    rainfall=climate_data['rain']['1h'] if 'rain' in climate_data else 0,
                    date=datetime.now()
                )
                self.stdout.write(self.style.SUCCESS('Climate data fetched and saved successfully!'))
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'Error parsing climate data: {e}'))
        else:
            self.stdout.write(self.style.ERROR(f'Failed to fetch climate data. Status code: {response.status_code}'))