# routing.py
from django.urls import path
from .views import chat

websocket_urlpatterns = [
    path("ws/chat/", chat.ChatConsumer.as_asgi()),
]
