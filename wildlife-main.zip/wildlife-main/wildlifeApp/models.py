# wildlife/models.py
from django.contrib.auth.models import User

from django.db import models

class WildlifeObservation(models.Model):
    species = models.CharField(max_length=100)
    location_lat = models.FloatField()
    location_long = models.FloatField()
    observation_time = models.DateTimeField(auto_now_add=True)
    image_url = models.URLField(blank=True, null=True)  # Optional image URL

    def __str__(self):
        return f"{self.species} at {self.location_lat}, {self.location_long}"
class ClimateData(models.Model):
    temperature = models.FloatField()
    humidity = models.FloatField()
    observation_time = models.DateTimeField(auto_now_add=True)
    city = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.city} at {self.observation_time}"

class MigrationData(models.Model):
    species = models.CharField(max_length=100)
    migration_period = models.CharField(max_length=100)
    location = models.CharField(max_length=100)
    population = models.IntegerField()

    def __str__(self):
        return self.species
    
class ChatMessage(models.Model):
    user = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)  # Allow anonymous
    content = models.TextField()
    is_user = models.BooleanField(default=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    session_key = models.CharField(max_length=40, blank=True, null=True)  # Track anonymous sessions

    def __str__(self):
        return f"{self.user.username if self.user else 'Anonymous'} - {'User' if self.is_user else 'Bot'} - {self.timestamp}"
    
class MammalMigration(models.Model):
    species = models.CharField(max_length=100)
    migration_period = models.CharField(max_length=100)
    location = models.CharField(max_length=100)
    population = models.IntegerField()
    latitude = models.FloatField()
    longitude = models.FloatField()

class APIUsage(models.Model):
    api_key = models.CharField(max_length=128)
    total_tokens = models.IntegerField(default=0)
    used_tokens = models.IntegerField(default=0)
    last_updated = models.DateTimeField(auto_now=True)

