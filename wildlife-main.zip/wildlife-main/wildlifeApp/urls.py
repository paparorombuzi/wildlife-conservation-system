from django.urls import path,include, re_path
from rest_framework.routers import DefaultRouter

from .views import migration_views
from rest_framework.authtoken.views import obtain_auth_token  # DRF's built-in view

from .views import climate_views, deforestation_views, migration_views, species_views, crime_views,plant_data,chat,api_views,Login_views
from django.urls import path

router = DefaultRouter()
# router.register(r'mammal_migration', migration_views.MigrationDataViewSet)
# websocket_urlpatterns = [
#     path(r'ws/chat/$', chat.ChatConsumer.as_asgi()),
# ]
urlpatterns = [
# urls.py
    path("plant_data/", plant_data.FetchPlantData.as_view(), name="plant_data"),

    path('chat/', chat.AIChat.as_view(), name='chat'),

    path('chat_history/', chat.AIChat.as_view(), name='chat_history'),

    path("climate_current/", climate_views.get_climate_data, name="current_climate"),

    path("climate_dataset/", climate_views.FetchClimateData.as_view(), name="climate_dataset"),

    path("deforestation/", deforestation_views.get_deforestation_data, name="deforestation"),

    path("forest_change/", deforestation_views.get_forest_change, name="forest_change"),
   
    path('species_data/', species_views.FetchSpeciesData.as_view(), name='species_data'),
    
    path('wildlife_crime/', crime_views.FetchWildlifeCrimeData.as_view(), name='species_data'),

    path('migration_data/', migration_views.FetchMigrationData.as_view(), name='migration_data'),

    path('api_usage/', api_views.get_usage, name='api_usage'),  # Changed endpoint
    path('api_auth-token/', obtain_auth_token, name='api_token_auth'),


    
     path('', include(router.urls)),
    path('send-otp/', Login_views.SendOTPView.as_view(), name='send-otp'),
      path('login/', Login_views.LoginView.as_view(), name='login'),
    path('register/', Login_views.RegisterView.as_view(), name='register'),
]


