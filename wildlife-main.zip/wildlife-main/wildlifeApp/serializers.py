from rest_framework import serializers
from .models import MigrationData

class MigrationDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = MigrationData
        fields = '__all__'