// src/App.jsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { GoogleOAuthProvider } from '@react-oauth/google';

import { AuthProvider } from './contexts/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';

import Navbar from './components/Navbar';
import Home from './components/Home';
import WildlifeCrime from './components/WildlifeCrime';
import Deforestation from './components/Deforestation';
import Migration from './components/Migration';
import Species from './components/Species';
import ClimateData from './components/ClimateData';
import Chat from './components/Chat';
import Api from './components/Api';

import Login from './components/Login';
import Register from './components/Register';

function App() {
  return (
    <GoogleOAuthProvider clientId="331450312488-lavpfaas8tgdpjk2ij7tnns8hl5j732h.apps.googleusercontent.com">
      <AuthProvider>
        <Router>
          <Navbar />
          <Routes>
            {/* Public */}
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />

            {/* Protected */}
            <Route element={<ProtectedRoute />}>
              <Route path="/" element={<Home />} />
              <Route path="/wildlife_crime" element={<WildlifeCrime />} />
              <Route path="/deforestation" element={<Deforestation />} />
              <Route path="/migration" element={<Migration />} />
              <Route path="/species" element={<Species />} />
              <Route path="/climate_data" element={<ClimateData />} />
              <Route path="/chat" element={<Chat />} />
              <Route path="/api_history" element={<Api />} />
            </Route>
          </Routes>
        </Router>
      </AuthProvider>
    </GoogleOAuthProvider>
  );
}

export default App;