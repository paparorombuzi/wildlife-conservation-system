// Deforestation.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import { Line, Bar, Pie } from "react-chartjs-2";
import Papa from "papaparse";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import HeatmapLayer from "./HeatmapLayer";

import {
  Chart as ChartJS,
  LineElement,
  BarElement,
  ArcElement, 
  PointElement,
  CategoryScale,
  LinearScale,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

// Import react-icons for UI enhancements
import { FaFire, FaTree, FaCalendarAlt, FaChartPie } from "react-icons/fa";

// Import Leaflet and marker images to fix the default marker icon issue
import L from "leaflet";
import markerIcon2x from "leaflet/dist/images/marker-icon-2x.png";
import markerIcon from "leaflet/dist/images/marker-icon.png";
import markerShadow from "leaflet/dist/images/marker-shadow.png";

// Fix the default marker icon issue
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

// Register Chart.js components
ChartJS.register(
  LineElement,
  BarElement,
  ArcElement, 
  PointElement,
  CategoryScale,
  LinearScale,
  Title,
  Tooltip,
  Legend
);

const Deforestation = ({ isSidebarOpen }) => {
  const [deforestationData, setDeforestationData] = useState([]);
  const [forestChangeData, setForestChangeData] = useState([]);
  const [filters, setFilters] = useState({
    startDate: "",
    endDate: "",
    confidence: "",
    minBrightness: "",
  });
  const [filteredData, setFilteredData] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch and cache deforestation data
  useEffect(() => {
    const cachedDeforestation = localStorage.getItem("deforestationData");
    if (cachedDeforestation) {
      const parsedData = JSON.parse(cachedDeforestation);
      setDeforestationData(parsedData);
      setFilteredData(parsedData);
    }

    axios
      .get("http://127.0.0.1:8000/api/deforestation/")
      .then((response) => {
        console.log("Deforestation API Response:", response.data);
        // Parse CSV data using PapaParse
        Papa.parse(response.data.data, {
          header: true,
          dynamicTyping: true,
          complete: (result) => {
            if (result.errors.length > 0) {
              console.error("CSV parsing errors:", result.errors);
              setDeforestationData([]);
            } else {
              setDeforestationData(result.data);
              setFilteredData(result.data);
              localStorage.setItem("deforestationData", JSON.stringify(result.data));
            }
            setLoading(false);
          },
        });
      })
      .catch((error) => {
        console.error("Error fetching deforestation data:", error);
        setDeforestationData([]);
        setLoading(false);
      });
  }, []);

  // Fetch and cache forest change data
  useEffect(() => {
    const cachedForestChange = localStorage.getItem("forestChangeData");
    if (cachedForestChange) {
      setForestChangeData(JSON.parse(cachedForestChange));
    }

    axios
      .get("http://127.0.0.1:8000/api/forest-change/")
      .then((response) => {
        console.log("Forest Change API Response:", response.data);
        const data = response.data;
        if (Array.isArray(data)) {
          setForestChangeData(data);
          localStorage.setItem("forestChangeData", JSON.stringify(data));
        } else {
          console.error("Invalid forest change data format", response.data);
          setForestChangeData([]);
        }
      })
      .catch((error) => {
        console.error("Error fetching forest change data:", error);
        setForestChangeData([]);
      });
  }, []);

  // Apply filters to the deforestation data
  useEffect(() => {
    let filtered = deforestationData;
    if (filters.startDate) {
      filtered = filtered.filter((item) => item.acq_date >= filters.startDate);
    }
    if (filters.endDate) {
      filtered = filtered.filter((item) => item.acq_date <= filters.endDate);
    }
    if (filters.confidence) {
      filtered = filtered.filter((item) => item.confidence === filters.confidence);
    }
    if (filters.minBrightness) {
      filtered = filtered.filter((item) => item.bright_ti4 >= parseFloat(filters.minBrightness));
    }
    setFilteredData(filtered);
  }, [filters, deforestationData]);

  // Summary statistics
  const totalEvents = filteredData.length;
  const avgBrightness = totalEvents
    ? (filteredData.reduce((sum, item) => sum + item.bright_ti4, 0) / totalEvents).toFixed(2)
    : 0;
  const maxFRP = totalEvents ? Math.max(...filteredData.map((item) => item.frp)) : 0;

  // Chart data for deforestation
  const deforestationChartData = {
    labels: filteredData.map((item) => item.acq_date),
    datasets: [
      {
        label: "Deforestation Brightness",
        data: filteredData.map((item) => item.bright_ti4),
        borderColor: "#8B4513", // SaddleBrown
        backgroundColor: "rgba(139,69,19,0.1)",
        fill: true,
      },
    ],
  };

  // Chart data for forest change
  const forestChangeChartData = {
    labels: forestChangeData.map((item) => item.year),
    datasets: [
      {
        label: "Forest Change (%)",
        data: forestChangeData.map((item) => item.change),
        backgroundColor: "#CD853F", // Peru
      },
    ],
  };

  // Pie chart data for confidence levels with no segment borders
  const confidenceData = {
    labels: ["Nominal", "Low", "High"],
    datasets: [
      {
        data: [
          filteredData.filter((item) => item.confidence === "n").length,
          filteredData.filter((item) => item.confidence === "l").length,
          filteredData.filter((item) => item.confidence === "h").length,
        ],
        backgroundColor: ["#8B4513", "#A0522D", "#D2B48C"],
        borderWidth: 0, // Removes borders between segments
      },
    ],
  };

  // Prepare heatmap data: [latitude, longitude, intensity]
  const heatmapData = filteredData.map((item) => [item.latitude, item.longitude, item.bright_ti4]);

  return (
    <div className={`transition-all duration-300 ${isSidebarOpen ? "ml-48" : "ml-16"} p-6`} style={{ backgroundColor: "" }}>
      <h1 className="text-3xl font-bold text-center mb-6 text-brown-800 animate-fadeIn">Deforestation Dashboard</h1>
      
      {loading && (
        <div className="flex justify-center items-center mb-6">
          <div className="w-12 h-12 border-4 border-t-4 border-[#8B4513] border-t-transparent rounded-full animate-spin"></div>
        </div>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 animate-fadeIn">
        <div className="bg-gradient-to-r from-brown-300 to-brown-500 p-4 shadow-lg rounded-lg hover:shadow-2xl transition-shadow">
          <h3 className="text-xl font-semibold flex items-center gap-2 text-brown-800">
            <FaFire /> Total Events
          </h3>
          <p className="text-3xl text-brown-900">{totalEvents}</p>
        </div>
        <div className="bg-gradient-to-r from-brown-300 to-brown-500 p-4 shadow-lg rounded-lg hover:shadow-2xl transition-shadow">
          <h3 className="text-xl font-semibold flex items-center gap-2 text-brown-800">
            <FaTree /> Avg. Brightness
          </h3>
          <p className="text-3xl text-brown-900">{avgBrightness}</p>
        </div>
        <div className="bg-gradient-to-r from-brown-300 to-brown-500 p-4 shadow-lg rounded-lg hover:shadow-2xl transition-shadow">
          <h3 className="text-xl font-semibold flex items-center gap-2 text-brown-800">
            <FaChartPie /> Max FRP
          </h3>
          <p className="text-3xl text-brown-900">{maxFRP}</p>
        </div>
      </div>
      
      {/* Informational Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3  gap-4 mb-6 animate-fadeIn">
        <div className="bg-gray-50 p-3 rounded-lg">
          <h3 className="text-lg font-semibold mb-2 text-brown-700">Brightness Temperature</h3>
          <p className="text-sm font-medium text-gray-600">
            Brightness temperature (<strong>bright_ti4</strong>) above <strong>330K</strong> often indicates fire or deforestation activity.
          </p>
        </div>
        <div className="bg-gray-50 p-3 rounded-lg">
          <h3 className="text-lg font-semibold mb-2 text-brown-700">Fire Radiative Power (FRP)</h3>
          <p className="text-sm font-medium text-gray-600">
            FRP measures the intensity of fires. Higher values (e.g., <strong>&gt; 10 MW</strong>) indicate more intense fires.
          </p>
        </div>
        <div className="bg-gray-50 p-3 rounded-lg">
          <h3 className="text-lg font-semibold mb-2 text-brown-700">Confidence Levels</h3>
          <p className="text-sm font-medium text-gray-600">
            Confidence levels: <strong>n</strong> (nominal), <strong>l</strong> (low), <strong>h</strong> (high).
          </p>
        </div>
      </div>
      
      {/* Filters */}
      <div className="bg-slate-50 p-6  rounded-xl mb-6 animate-fadeIn text-brown-700">
  <h2 className="text-xl font-semibold mb-4 flex items-center gap-2 text-brown-700">
    <FaCalendarAlt className="text-brown-700" /> Filters
  </h2>
  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
    <input
      type="date"
      placeholder="Start Date"
      value={filters.startDate}
      onChange={(e) => setFilters({ ...filters, startDate: e.target.value })}
      className="p-3 bg-white/20 text-brown-700 border border-brown-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-text-brown-700 transition duration-200 placeholder-text-brown-700"
    />
    <input
      type="date"
      placeholder="End Date"
      value={filters.endDate}
      onChange={(e) => setFilters({ ...filters, endDate: e.target.value })}
      className="p-3 bg-white/20 text-brown-700 border border-brown-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-text-brown-700 transition duration-200 placeholder-text-brown-700"
    />
    <select
      value={filters.confidence}
      onChange={(e) => setFilters({ ...filters, confidence: e.target.value })}
      className="p-3 bg-white/20 text-brown-700 border border-brown-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-text-brown-700 transition duration-200"
    >
      <option value="">All Confidence</option>
      <option value="n">Nominal</option>
      <option value="l">Low</option>
      <option value="h">High</option>
    </select>
    <input
      type="number"
      placeholder="Min Brightness (K)"
      value={filters.minBrightness}
      onChange={(e) => setFilters({ ...filters, minBrightness: e.target.value })}
      className="p-3 bg-white/20 text-brown-700 border border-brown-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-white/60 transition duration-200 placeholder-text-brown-700"
    />
  </div>
</div>

        {/* charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6 animate-fadeIn">
        <div className=" p-4  rounded-lg">
          <h2 className="text-lg font-semibold mb-2 text-brown-700">Deforestation Over Time</h2>
          {filteredData.length > 0 ? (
            <Line data={deforestationChartData} />
          ) : (
            <p className="text-gray-500">No deforestation data available</p>
          )}
        </div>
        <div className=" p-4  rounded-lg">
          <h2 className="text-lg font-semibold mb-2 text-brown-700">Confidence Levels</h2>
          <Pie data={confidenceData} />
        </div>
      </div>
      {/* World Map with Heatmap */}
      <div className="bg-white p-4 shadow-lg rounded-lg mb-6 animate-fadeIn">
        <h2 className="text-lg font-semibold mb-2 text-brown-700">Deforestation Locations</h2>
        <MapContainer center={[0, 0]} zoom={2}  className="h-[100vh] w-full rounded-lg"
        style={{ filter: 'sepia(0.6)' }} // brownish, wildlife-inspired filter 
        >
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          />
          <HeatmapLayer points={heatmapData} options={{ radius: 15, blur: 10, max: 400 }} />
          {filteredData.map((item, index) => (
            <Marker key={index} position={[item.latitude, item.longitude]}>
              <Popup>
                <div>
                  <strong>Date:</strong> {item.acq_date} <br />
                  <strong>Brightness:</strong> {item.bright_ti4}K <br />
                  <strong>FRP:</strong> {item.frp} MW
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      </div>

      {/* Charts */}

      <div className="bg-white p-4 shadow-lg rounded-lg animate-fadeIn">
        <h2 className="text-lg font-semibold mb-2 text-brown-700">Forest Change</h2>
        {forestChangeData.length > 0 ? (
          <Bar data={forestChangeChartData} />
        ) : (
          <p className="text-gray-500">No forest change data available</p>
        )}
      </div>
    </div>
  );
};

export default Deforestation;
