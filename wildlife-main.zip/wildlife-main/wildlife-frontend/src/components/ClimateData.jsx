import React, { useState, useEffect } from 'react';
import WeatherForecastChart from './dependancy/WeatherForecastChart';
import WildlifeMap from './dependancy/WildlifeMap';
import WeatherAlert from './dependancy/WeatherAlert';
import WeatherDetails from './dependancy/WeatherDetails'; // Import the new component

const ClimateData = ({ isSidebarOpen }) => {
  const [forecastData, setForecastData] = useState([]);
  const [weatherAlert, setWeatherAlert] = useState(null);
  const [mapData, setMapData] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8000/api/climate_dataset/')
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        console.log("Raw data from backend:", data); // Log raw data
        const formattedData = data.map(item => ({
          dt_txt: item.dt_txt,
          temp: item.main.temp,
          humidity: item.main.humidity,
          wind: item.wind,
          main: item.main,
          weather: item.weather,
          visibility: item.visibility,
        }));
        console.log("Formatted data for chart:", formattedData); // Log formatted data
        setForecastData(formattedData);

        const alertCondition = data.find(item => item.main.temp > 35 || item.main.temp < 5);
        if (alertCondition) {
          setWeatherAlert(`Extreme temperature alert: ${alertCondition.main.temp}°C at ${alertCondition.dt_txt}`);
        }

        const mapItems = data.map(item => ({
          lat: -1.2921 + Math.random() * 0.1,
          lon: 36.8219 + Math.random() * 0.1,
          description: `${item.dt_txt}: ${item.main.temp}°C`,
        }));
        setMapData(mapItems);
      })
      .catch(error => console.error('Error fetching weather data:', error));
  }, []);

  return (
    <div className={`transition-all duration-300  ${isSidebarOpen ? 'ml-64' : 'ml-16'} p-4`}>
      <div className='p-4'>
      <h1 className="text-3xl font-bold text-center text-brown-700">Wildlife Weather System</h1>
      {weatherAlert && <WeatherAlert alertMessage={weatherAlert} />}
      <div className="my-8">
        <h2 className="text-2xl font-semibold mb-4">Temperature Trends</h2>
        <WeatherForecastChart data={forecastData} />
      </div>
      <div className="my-8">
        <h2 className="text-2xl font-semibold mb-4">Weather Details</h2>
        <WeatherDetails data={forecastData} /> {/* Add the new component */}
      </div>
      <div className="my-8">
        <h2 className="text-2xl font-semibold mb-4">Wildlife Map</h2>
        <WildlifeMap lat={-1.2921} lon={36.8219} weatherData={mapData} />
      </div>
      </div>
    </div>
  );
};

export default ClimateData;