import React, { useEffect, useState, useMemo } from "react";
import axios from "axios";
import { Bar, Doughnut } from "react-chartjs-2";
import { MapContainer, TileLayer, Marker, Popup, Polyline, Tooltip } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { FaGlobe, FaChartBar, FaChartPie, FaRoute, FaSpinner, FaInfoCircle, FaCalendarAlt } from "react-icons/fa";
import { motion } from "framer-motion";

// Custom marker icon with a wildlife theme
const customIcon = L.icon({
  iconUrl: "https://www.freeiconspng.com/uploads/nature-icon-27.png",
  iconSize: [40, 40],
  iconAnchor: [20, 40],
  popupAnchor: [0, -40],
});

// Helper function: compute distance (in km) between two coordinates using the Haversine formula
const haversineDistance = (lat1, lon1, lat2, lon2) => {
  const toRad = (value) => (value * Math.PI) / 180;
  const R = 6371; // Earth's radius in km
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

// Helper function to extract numerical population values
const extractPopulation = (populationValue) => {
  if (typeof populationValue !== "string") {
    return populationValue;
  }
  if (populationValue.includes("million")) {
    return parseFloat(populationValue.replace(/[^0-9.]/g, "")) * 1000000;
  }
  return parseFloat(populationValue.replace(/[^0-9.]/g, ""));
};

const Migration = ({ isSidebarOpen }) => {
  const [migrationData, setMigrationData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchData = async () => {
    try {
      const response = await axios.get("http://localhost:8000/api/migration_data/");
      setMigrationData(response.data);
      localStorage.setItem("migrationData", JSON.stringify(response.data));
      setError(null);
    } catch (error) {
      console.error("Error fetching migration data:", error);
      setError("Failed to fetch migration data. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const cachedData = localStorage.getItem("migrationData");
    if (cachedData) {
      setMigrationData(JSON.parse(cachedData));
      setLoading(false);
    }
    fetchData();
  }, []);

  // Chart data for migration distance
  const migrationDistanceData = useMemo(() => {
    const distances = migrationData.map((data) => {
      if (
        data.from_latitude != null &&
        data.from_longitude != null &&
        data.latitude != null &&
        data.longitude != null
      ) {
        return haversineDistance(
          data.from_latitude,
          data.from_longitude,
          data.latitude,
          data.longitude
        ).toFixed(2);
      }
      return 0;
    });
    return {
      labels: migrationData.map((data) => data.species),
      datasets: [
        {
          label: "Migration Distance (km)",
          data: distances,
          backgroundColor: "#8B4513", // Brownish color
          borderColor: "#4A2B0F",
          borderWidth: 1,
        },
      ],
    };
  }, [migrationData]);

  // Chart data for migration period timeline
  const migrationPeriodData = useMemo(() => {
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  
    const offsets = migrationData.map((data) => {
      if (!data.migration_period) return 0; // Default offset if undefined
      const parts = data.migration_period.split(" to ");
      if (parts.length < 2) return 0;
      const [start, end] = parts;
      const startMonth = months.indexOf(start.split(" ")[0]) + 1;
      return startMonth;
    });
  
    const durations = migrationData.map((data) => {
      if (!data.migration_period) return 0; // Default duration if undefined
      const parts = data.migration_period.split(" to ");
      if (parts.length < 2) return 0;
      const [start, end] = parts;
      const startMonth = months.indexOf(start.split(" ")[0]) + 1;
      const endMonth = months.indexOf(end.split(" ")[0]) + 1;
      return endMonth - startMonth;
    });
  
    return {
      labels: migrationData.map((data) => data.species),
      datasets: [
        {
          label: "Offset",
          data: offsets,
          backgroundColor: "#F4A460", // Invisible offset
          stack: "combined",
        },
        {
          label: "Migration Period",
          data: durations,
          backgroundColor: "#8B4513",
          borderColor: "#4A2B0F",
          borderWidth: 1,
          stack: "combined",
        },
      ],
    };
  }, [migrationData]);
  
  
  

  // Chart data for population distribution
  const populationDistributionData = useMemo(() => {
    return {
      labels: migrationData.map((data) => data.species),
      datasets: [
        {
          label: "Population",
          data: migrationData.map((data) => extractPopulation(data.population)),
          backgroundColor: ["#8B4513", "#A0522D", "#D2691E", "#CD853F", "#F4A460"], // Brownish colors
          borderColor: "#4A2B0F",
          borderWidth: 1,
        },
      ],
    };
  }, [migrationData]);

  // Map center
  const firstValid = migrationData.find(
    (data) => data.latitude != null && data.longitude != null
  );
  const mapCenter = firstValid ? [firstValid.latitude, firstValid.longitude] : [0, 0];

  // Summary stats
  const totalSpecies = useMemo(() => new Set(migrationData.map(data => data.species)).size, [migrationData]);
  const totalPopulation = useMemo(() => migrationData.reduce((acc, cur) => acc + extractPopulation(cur.population), 0), [migrationData]);

  return (
    <div className={`p-10 ${isSidebarOpen ? "ml-48" : "ml-16"}  min-h-screen transition-all duration-300`}>
      <motion.h1 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-4xl font-bold text-brown-900 text-center mb-8 flex items-center justify-center gap-3"
      >
        <FaGlobe className="text-brown-700 animate-spin-slow" />
        Wildlife Migration Dashboard
        <FaRoute className="text-brown-700 animate-pulse" />
      </motion.h1>

      {loading && (
        <div className="flex flex-col items-center justify-center h-64">
          <div className="w-16 h-16 border-4 border-brown-700 border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-4 text-brown-700 flex items-center gap-2">
            <FaSpinner /> Loading Migration Data...
          </p>
        </div>
      )}

      {error && (
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg max-w-md mx-auto flex items-center gap-3"
        >
          <FaInfoCircle />
          {error}
        </motion.div>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="bg-gradient-to-r from-brown-300 to-brown-500 rounded-xl shadow-lg p-6 border-2 border-brown-100"
        >
          <h2 className="text-xl font-bold text-brown-900 mb-3 flex items-center gap-2">
            <FaGlobe /> Total Species
          </h2>
          <p className="text-3xl font-bold text-brown-700">{totalSpecies}</p>
        </motion.div>
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="bg-gradient-to-r from-brown-300 to-brown-500 rounded-xl shadow-lg p-6 border-2 border-brown-100"
        >
          <h2 className="text-xl font-bold text-brown-900 mb-3 flex items-center gap-2">
            <FaChartBar /> Total Population
          </h2>
          <p className="text-3xl font-bold text-brown-700">{totalPopulation.toLocaleString()}</p>
        </motion.div>
      </div>

      {/* Migration Cards */}
      <motion.div
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="border-brown-100"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {migrationData.map((data, index) => (
            <div
              key={index}
              className="bg-gray-50 p-3 rounded-lg"
            >
              <h2 className="text-xl font-bold mb-3" style={{ color: "#4b3621" }}>{data.species}</h2>
              <p className="text-gray-700"><strong>Migration Period:</strong> {data.migration_period}</p>
              <p className="text-gray-700"><strong>From:</strong> {data.from_location}</p>
              <p className="text-gray-700"><strong>To:</strong> {data.location}</p>
              <p className="text-gray-700"><strong>Population:</strong> {data.population}</p>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Charts */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="bg-white p-3 "
        >
          <h2 className="text-2xl font-bold text-brown-700 mb-4 flex items-center gap-2">
            <FaCalendarAlt /> Migration Period Timeline
          </h2>
          <Bar
              data={migrationPeriodData}
              options={{
                indexAxis: "y",
                scales: {
                  x: {
                    stacked: true,
                    min: 1,
                    max: 12,
                    ticks: {
                      callback: (value) => {
                        const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                        return months[value - 1];
                      },
                    },
                  },
                  y: {
                    stacked: true,
                  },
                },
              }}
            />
        </motion.div>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="bg-white p-3 ">
          <h2 className="text-2xl font-bold text-brown-700 mb-4 flex items-center gap-2">
            <FaChartPie /> Population Distribution
          </h2>
          <Doughnut data={populationDistributionData} />
        </motion.div>
      </div>

      {/* World Map */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="p-1 mb-10"
      >
        <h2 className="text-xl font-bold text-brown-700 mb-4 flex items-center gap-2">
          <FaGlobe /> Migration Routes
        </h2>
        <MapContainer center={mapCenter} zoom={3} className="h-[100vh] w-full rounded-lg"
        style={{ filter: 'sepia(0.6)' }} // brownish, wildlife-inspired filter 
        >
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution='&copy; OpenStreetMap contributors'
          />
          {migrationData.map((data, index) => {
            if (data.from_latitude != null && data.from_longitude != null && data.latitude != null && data.longitude != null) {
              return (
                <React.Fragment key={index}>
                  <Marker position={[data.from_latitude, data.from_longitude]} icon={customIcon}>
                    <Popup>
                      <b>{data.species} (Origin)</b>
                      <br />
                      {data.from_location}
                    </Popup>
                  </Marker>
                  <Marker position={[data.latitude, data.longitude]} icon={customIcon}>
                    <Popup>
                      <b>{data.species} (Destination)</b>
                      <br />
                      {data.location}
                      <br />
                      Population: {data.population}
                    </Popup>
                  </Marker>
                  <Polyline positions={[[data.from_latitude, data.from_longitude], [data.latitude, data.longitude]]} color="#8B4513" weight={2}>
                    <Tooltip direction="top" offset={[0, -10]}>
                      <strong>{data.species}</strong>
                    </Tooltip>
                  </Polyline>
                </React.Fragment>
              );
            }
            return null;
          })}
        </MapContainer>
      </motion.div>
    </div>
  );
};

export default Migration;