import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Menu, Home, TreePalm, Globe, PawPrint, X, AirVent } from "lucide-react";
import { FaRoute, FaRobot } from "react-icons/fa";
import { useAuth } from '../contexts/AuthContext';

const Navbar = () => {
  const { isLoggedIn, logout } = useAuth();
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(() => {
    const savedState = localStorage.getItem("navbarOpen");
    return savedState ? JSON.parse(savedState) : false;
  });

  useEffect(() => {
    localStorage.setItem("navbarOpen", JSON.stringify(isOpen));
  }, [isOpen]);

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  // Don't render navbar if not logged in
  if (!isLoggedIn) {
    return null;
  }

  return (
    <nav className="bg-gray-900 text-white p-4 fixed top-0 left-0 h-full z-30">
      {/* Hamburger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="text-white focus:outline-none mb-4"
      >
        {isOpen ? <X size={28} /> : <Menu size={28} />}
      </button>

      {/* Navigation Links */}
      <ul className={`space-y-6 ${isOpen ? "w-48" : "w-14"} transition-all`}>
        <li>
          <Link to="/" className="flex items-center space-x-3">
            <Home size={24} />
            {isOpen && <span>Home</span>}
          </Link>
        </li>
        <li>
          <Link to="/wildlife_crime" className="flex items-center space-x-3">
            <Globe size={24} />
            {isOpen && <span>Wildlife Crime</span>}
          </Link>
        </li>
        <li>
          <Link to="/deforestation" className="flex items-center space-x-3">
            <TreePalm size={24} />
            {isOpen && <span>Deforestation</span>}
          </Link>
        </li>
        <li>
          <Link to="/migration" className="flex items-center space-x-3">
            <FaRoute size={24} />
            {isOpen && <span>Migration</span>}
          </Link>
        </li>
        <li>
          <Link to="/species" className="flex items-center space-x-3">
            <PawPrint size={24} />
            {isOpen && <span>Species</span>}
          </Link>
        </li>
        <li>
          <Link to="/climate_data" className="flex items-center space-x-3">
            <AirVent size={24} />
            {isOpen && <span>Climate Data</span>}
          </Link>
        </li>
        <li>
          <Link to="/chat" className="flex items-center space-x-3">
            <FaRobot size={24} />
            {isOpen && <span>Chat</span>}
          </Link>
        </li>
        <li>
          <button 
            onClick={handleLogout}
            className="flex items-center space-x-3 w-full text-left"
          >
            {isOpen ? "Logout" : "🚪"}
          </button>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;