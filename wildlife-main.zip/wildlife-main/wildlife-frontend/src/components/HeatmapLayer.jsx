// HeatmapLayer.jsx
import { useEffect } from "react";
import { useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet.heat";


const HeatmapLayer = ({ points, options }) => {
  const map = useMap();

  useEffect(() => {
    const heatLayer = L.heatLayer(points, options);
    heatLayer.addTo(map);

    // Clean up the layer when component unmounts or options/points change
    return () => {
      map.removeLayer(heatLayer);
    };
  }, [map, points, options]);

  return null;
};

export default HeatmapLayer;
