import React, { useEffect, useState, useMemo } from "react";
import axios from "axios";

import Charts from "./dependancy/Charts";
import Map from "./dependancy/Map";
import DataTable from "./dependancy/DataTable";
import { calculateKPIs, getTrends, getDistribution, getMarkers } from "./dependancy/dataUtils";
import { Doughnut, Bar } from "react-chartjs-2";
import Papa from "papaparse";
import { motion } from "framer-motion";
import { FaLeaf, FaSearch, FaFilter, FaDownload } from "react-icons/fa";

const Home = ({ isSidebarOpen }) => {
  const [plantData, setPlantData] = useState([]);
  const [deforestationData, setDeforestationData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState({
    location: "All",
    status: "All",
    biodiversityIndexRange: [0, 1],
  });
  const [searchQuery, setSearchQuery] = useState("");

  // Load data from LocalStorage on initial render
  useEffect(() => {
    const savedPlantData = localStorage.getItem("plantData");
    const savedFilters = localStorage.getItem("filters");
    if (savedPlantData) setPlantData(JSON.parse(savedPlantData));
    if (savedFilters) setFilters(JSON.parse(savedFilters));
  }, []);

  // Save data to LocalStorage whenever plantData or filters change
  useEffect(() => {
    localStorage.setItem("plantData", JSON.stringify(plantData));
    localStorage.setItem("filters", JSON.stringify(filters));
  }, [plantData, filters]);

  // Fetch and cache all data
  useEffect(() => {
    const fetchAll = async () => {
      try {
        const [plantRes, defRes] = await Promise.all([
          axios.get("http://127.0.0.1:8000/api/plant_data/").catch(() => ({ data: [] })),
          axios.get("http://127.0.0.1:8000/api/deforestation/").catch(() => ({ data: [] })),
        ]);

        console.log("Plant Data:", plantRes.data);
        console.log("Deforestation Data:", defRes.data);

        setPlantData(plantRes.data || []);
        setDeforestationData(defRes.data || []);
        setError(null);
      } catch (err) {
        console.error("Error fetching data", err);
        setError("An error occurred while fetching data.");
      } finally {
        setLoading(false);
      }
    };

    fetchAll();
  }, []);

  // Filter plant data based on filters and search query
  const filteredPlantData = useMemo(() => {
    return plantData.filter((plant) => {
      const matchesLocation = filters.location === "All" || plant.location === filters.location;
      const matchesStatus = filters.status === "All" || plant.status === filters.status;
      const matchesBiodiversityIndex =
        plant.biodiversity_index >= filters.biodiversityIndexRange[0] &&
        plant.biodiversity_index <= filters.biodiversityIndexRange[1];
      const matchesSearchQuery =
        plant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        plant.scientific_name.toLowerCase().includes(searchQuery.toLowerCase());

      return matchesLocation && matchesStatus && matchesBiodiversityIndex && matchesSearchQuery;
    });
  }, [plantData, filters, searchQuery]);

  // Calculate KPIs for plant data
  const plantKPIs = useMemo(() => calculateKPIs(filteredPlantData), [filteredPlantData]);

  // Calculate KPIs for deforestation data
  const deforestationKPIs = useMemo(() => {
    if (!deforestationData || !Array.isArray(deforestationData)) {
      return { totalEvents: 0, avgBrightness: 0, maxFRP: 0 };
    }
    const totalEvents = deforestationData.length;
    const avgBrightness =
      totalEvents > 0
        ? deforestationData.reduce((sum, item) => sum + item.bright_ti4, 0) / totalEvents
        : 0;
    const maxFRP = totalEvents > 0 ? Math.max(...deforestationData.map((item) => item.frp)) : 0;
    return { totalEvents, avgBrightness, maxFRP };
  }, [deforestationData]);

  // Generate chart data for plant biodiversity trends
  const plantTrends = useMemo(() => getTrends(filteredPlantData), [filteredPlantData]);

  // Generate chart data for plant distribution
  const plantDistribution = useMemo(() => getDistribution(filteredPlantData), [filteredPlantData]);

  // Generate markers for the map
  const markers = useMemo(
    () => getMarkers(filteredPlantData, deforestationData),
    [filteredPlantData, deforestationData]
  );

  // Export data as CSV
  const exportData = () => {
    const csv = Papa.unparse(filteredPlantData);
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "plant_data.csv";
    a.click();
  };

  return (
    <div className={`${isSidebarOpen ? "ml-48" : "ml-20"} bg-white min-h-screen`}>
      {/* Navigation Bar */}
      <div className="bg-green-700 text-white p-4 flex justify-between items-center mb-8">

        <h1 className="text-2xl font-bold flex items-center">
          <FaLeaf className="mr-2" /> Wildlife Plants Dashboard
        </h1>
        <nav>
          <ul className="flex space-x-4">
            <li><a href="#overview" className="hover:underline">Overview</a></li>
            <li><a href="#charts" className="hover:underline">Charts</a></li>
            <li><a href="#map" className="hover:underline">Map</a></li>
            <li><a href="#data" className="hover:underline">Data</a></li>
          </ul>
        </nav>
      </div>
  <div className="p-8">
      {/* Loading and Error States */}
      {loading && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center"
        >
          <p>Loading data...</p>
          <div className="w-12 h-12 border-4 border-green-500 border-t-transparent rounded-full animate-spin mx-auto mt-4"></div>
        </motion.div>
      )}
      {error && <p className="text-center text-red-500">{error}</p>}

      {/* Filters and Search Bar */}
      <div className="mb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-green-700">Location</label>
            <select
              value={filters.location}
              onChange={(e) => setFilters({ ...filters, location: e.target.value })}
              className="bg-white/20 text-green-700 border border-green-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-text-green-700 transition duration-200 placeholder-text-green-700 w-full p-2"
            >
              <option>All</option>
              <option>Sumatra, Indonesia</option>
              <option>Namib Desert, Namibia</option>
              <option>North and South Carolina, USA</option>
              <option>Madagascar</option>
              <option>Florida, USA and Cuba</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-green-700">Status</label>
            <select
              value={filters.status}
              onChange={(e) => setFilters({ ...filters, status: e.target.value })}
              className="bg-white/20 text-green-700 border border-green-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-text-green-700 transition duration-200 placeholder-text-green-700 w-full p-2"
            >
              <option>All</option>
              <option>Endangered</option>
              <option>Vulnerable</option>
            </select>
          </div>
          <div>
          <label className="block text-sm font-medium text-green-700">
            Biodiversity Index Range
          </label>
          <input
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={filters.biodiversityIndexRange[1]}
            onChange={(e) =>
              setFilters({ ...filters, biodiversityIndexRange: [0, parseFloat(e.target.value)] })
            }
            className="mt-1 block w-full accent-green-500"
          />
        </div>

        </div>
        <div className="relative">
          <FaSearch className="absolute left-3 top-3 text-gray-400" />
          <input
            type="text"
            placeholder="Search for plant species..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-white/70 text-green-700 border border-green-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-text-green-700 transition duration-200 placeholder-text-green-700 w-full pl-10 p-2"
          />
        </div>
      </div>

      {/* KPI Cards for Plant Data */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="bg-gradient-to-r from-green-200 to-green-400 p-4 rounded shadow cursor-pointer hover:shadow-lg transition-shadow"
        >
          <h2 className="text-lg font-semibold">Total Plant Species</h2>
          <p className="text-2xl">{plantKPIs.totalSpecies}</p>
        </motion.div>
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="bg-gradient-to-r from-green-200 to-green-400 p-4 rounded shadow cursor-pointer hover:shadow-lg transition-shadow"
        >
          <h2 className="text-lg font-semibold">Endangered Species</h2>
          <p className="text-2xl">{plantKPIs.endangeredSpecies}</p>
        </motion.div>
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="bg-gradient-to-r from-green-200 to-green-400 p-4 rounded shadow cursor-pointer hover:shadow-lg transition-shadow"
        >
          <h2 className="text-lg font-semibold">Avg. Biodiversity Index</h2>
          <p className="text-2xl">{plantKPIs.avgBiodiversityIndex.toFixed(2)}</p>
        </motion.div>
      </div>

      

      {/* Charts Section */}
      <section id="charts">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {/* Plant Biodiversity Trends Chart */}
          <div className=" p-4 rounded ">
            <h2 className="text-xl text-green-700 font-semibold mb-4">Plant Biodiversity Trends</h2>
            <Charts trends={plantTrends} />
          </div>

          {/* Plant Distribution Doughnut Chart */}
          <div className=" p-4 rounded ">
            <h2 className="text-xl text-green-700  font-semibold mb-4">Plant Distribution</h2>
            <div className="relative" style={{ height: "400px" }}>
              {plantDistribution?.labels?.length > 0 ? (
                <Doughnut
                  data={plantDistribution}
                  options={{ responsive: true, maintainAspectRatio: false }}
                />
              ) : (
                <p className="text-green-500">No plant distribution data available.</p>
              )}
            </div>
          </div>
        </div>
      </div>
      </section>

                    {/* Data Table and Export Button */}
      <section id="data">
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            onClick={exportData}
            className="bg-green-500 text-white p-2 rounded-md hover:bg-green-600 transition-colors flex items-center"
          >
            <FaDownload className="mr-2" /> Export Data as CSV
          </motion.button>
        </div>
        <DataTable data={filteredPlantData} />
      </div>
      </section>

      {/* Map Section */}
      <section id="map">
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Plant and Deforestation Map</h2>
        <Map markers={markers} />
      </div>
      </section>



      </div>
      {/* Footer */}
      <footer className="bg-green-800 text-white p-4 mt-8">
        <div className="text-center">
          <p>© 2025 Wildlife Plants Dashboard. All rights reserved.</p>
          <p>Built with ❤️ by Your Team</p>
        </div>

      </footer>
    </div>
  );
};

export default Home;