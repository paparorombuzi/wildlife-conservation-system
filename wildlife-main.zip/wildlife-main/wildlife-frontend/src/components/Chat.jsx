import React, { useState, useEffect, useRef } from 'react';
import { FaPaperPlane, FaRobot, FaUser, FaSpinner } from 'react-icons/fa';
import { SparklesIcon } from "@heroicons/react/24/outline";

const Chat = ({ isSidebarOpen }) => {
  const [messages, setMessages] = useState(() => {
    const savedMessages = localStorage.getItem('chatMessages');
    return savedMessages ? JSON.parse(savedMessages) : [];
  });
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Initial scroll to bottom when component mounts
  useEffect(() => {
    scrollToBottom();
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // Save messages to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('chatMessages', JSON.stringify(messages));
  }, [messages]);

  // Fetch chat history on component mount only if localStorage is empty
  useEffect(() => {
    if (messages.length > 0) return;

    const fetchChatHistory = async () => {
      try {
        const response = await fetch('http://127.0.0.1:8000/api/chat_history/');
        const data = await response.json();

        if (data.messages.length === 0) {
          const welcomeMessage = {
            id: Date.now(), 
            text: "Welcome to Osman Wildlife Conservation. How can I help you?",
            isUser: false,
            timestamp: new Date().toISOString(),
          };
          data.messages.unshift(welcomeMessage);
        }
        setMessages(data.messages);
      } catch (error) {
        console.error('Error fetching chat history:', error);
      }
    };
    fetchChatHistory();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const userMessage = {
      id: Date.now(),
      text: inputMessage,
      isUser: true,
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsLoading(true);

    try {
      const response = await fetch('http://127.0.0.1:8000/api/chat/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: inputMessage }),
      });

      const data = await response.json();
      const botMessage = {
        id: Date.now() + 1,
        text: data.response,
        isUser: false,
        timestamp: new Date().toISOString(),
      };

      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      console.error('Error:', error);
      setMessages(prev => [
        ...prev, 
        {
          id: Date.now(),
          text: 'Sorry, there was an error processing your request.',
          isUser: false,
          timestamp: new Date().toISOString(),
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={`${isSidebarOpen ? "ml-48" : "ml-20"} min-h-screen bg-gray-50 transition-all duration-300`}>
      <div className="flex flex-col h-screen">
        <div className="flex items-center p-4 border-b bg-white">
          <SparklesIcon className="h-8 w-8 text-amber-600 mr-2" />
          <h1 className="text-xl font-semibold text-amber-800">Wildlife Assistant</h1>
        </div>

        <div className="flex-1 overflow-y-auto mb-4 space-y-4 p-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.isUser ? 'justify-end' : 'justify-start'} items-start gap-3`}
            >
              {!message.isUser && (
                <div className="p-2 bg-amber-700 rounded-full text-white">
                  <FaRobot className="w-6 h-6" />
                </div>
              )}
              <div
                className={`max-w-xl p-4 rounded-lg ${
                  message.isUser 
                    ? 'bg-amber-600 text-white ml-20' 
                    : 'bg-amber-100 text-amber-900 mr-20'
                }`}
              >
                <p className="text-sm">{message.text}</p>
                <p className="text-xs mt-2 opacity-70">
                  {new Date(message.timestamp).toLocaleTimeString()}
                </p>
              </div>
              {message.isUser && (
                <div className="p-2 bg-amber-600 rounded-full text-white">
                  <FaUser className="w-6 h-6" />
                </div>
              )}
            </div>
          ))}
          {isLoading && (
            <div className="flex items-center justify-start gap-3">
              <div className="p-2 bg-amber-700 rounded-full text-white">
                <FaRobot className="w-6 h-6" />
              </div>
              <div className="bg-amber-100 p-4 rounded-lg">
                <FaSpinner className="animate-spin text-amber-600" />
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
        <div className='p-4'>
          <form onSubmit={handleSubmit} className="flex gap-2">
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 p-3 rounded-lg border border-amber-300 focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white"
            />
            <button
              type="submit"
              disabled={isLoading}
              className="p-3 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors disabled:opacity-50"
            >
              <FaPaperPlane className="w-5 h-5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Chat;