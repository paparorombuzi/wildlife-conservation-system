import React, { useState } from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import Input from './ui/input.jsx';
import Button from './ui/button.jsx';
import { Mail, ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom';

const Register = () => {
  const [email, setEmail] = useState('');
  const [stage, setStage] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const sendOtp = async () => {
    if (!email) {
      toast.error("Please enter your email");
      return;
    }
    
    setIsLoading(true);
    try {
      await axios.post('http://localhost:8000/api/send-otp/', { email });
      toast.success("OTP sent to your email");
      setStage(2);
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to send OTP");
    } finally {
      setIsLoading(false);
    }
  };

  const registerSchema = Yup.object().shape({
    first_name: Yup.string().required('First name is required'),
    last_name: Yup.string().required('Last name is required'),
    password: Yup.string()
      .min(8, 'Password must be at least 8 characters')
      .required('Password is required'),
    confirmPassword: Yup.string()
      .oneOf([Yup.ref('password')], 'Passwords must match')
      .required('Please confirm your password'),
    otp: Yup.string()
      .length(6, 'OTP must be 6 digits')
      .required('OTP is required'),
  });

  const handleRegister = async (values, { setSubmitting }) => {
    try {
      const payload = {
        email,
        otp: values.otp,
        password: values.password,
        first_name: values.first_name,
        last_name: values.last_name
      };
      await axios.post('http://localhost:8000/api/register/', payload);
      toast.success('Registration successful! Redirecting...');
      setTimeout(() => navigate("/"), 2000);
    } catch (error) {
      toast.error(error.response?.data?.message || 'Registration failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
      <ToastContainer position="top-center" autoClose={3000} />
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="bg-white p-8 rounded-xl shadow-xl w-full max-w-md mx-4"
      >
        {stage === 1 ? (
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-gray-800">Create Account</h2>
              <p className="text-gray-600 mt-2">Enter your email to get started</p>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail className="h-5 w-5 text-gray-400" />
                  </div>
                  <Input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    className="pl-10 w-full"
                    required
                  />
                </div>
              </div>
              
              <Button 
                onClick={sendOtp} 
                className="w-full mt-2"
                disabled={isLoading}
              >
                {isLoading ? 'Sending OTP...' : 'Continue with Email'}
              </Button>
            </div>
            
            <div className="text-center text-sm text-gray-600">
              Already have an account?{' '}
              <button 
                onClick={() => navigate('/login')} 
                className="text-blue-600 hover:text-blue-800 font-medium"
              >
                Sign in
              </button>
            </div>
          </div>
        ) : (
          <Formik
            initialValues={{
              first_name: '',
              last_name: '',
              password: '',
              confirmPassword: '',
              otp: ''
            }}
            validationSchema={registerSchema}
            onSubmit={handleRegister}
          >
            {({ isSubmitting, isValid, dirty }) => (
              <Form className="space-y-5">
                <div className="flex items-center mb-2">
                  <button
                    type="button"
                    onClick={() => setStage(1)}
                    className="text-gray-500 hover:text-gray-700 mr-2"
                  >
                    <ArrowLeft size={20} />
                  </button>
                  <h2 className="text-2xl font-bold text-gray-800">Complete Registration</h2>
                </div>
                <p className="text-sm text-gray-600 mb-6">
                  OTP sent to <span className="font-medium">{email}</span>
                </p>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">First Name</label>
                    <Field 
                      as={Input} 
                      name="first_name" 
                      placeholder="John" 
                    />
                    <ErrorMessage name="first_name" component="div" className="text-red-500 text-xs mt-1" />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
                    <Field 
                      as={Input} 
                      name="last_name" 
                      placeholder="Doe" 
                    />
                    <ErrorMessage name="last_name" component="div" className="text-red-500 text-xs mt-1" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">OTP Code</label>
                  <Field 
                    as={Input} 
                    name="otp" 
                    placeholder="123456" 
                  />
                  <ErrorMessage name="otp" component="div" className="text-red-500 text-xs mt-1" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                  <Field 
                    as={Input} 
                    type="password" 
                    name="password" 
                    placeholder="••••••••" 
                  />
                  <ErrorMessage name="password" component="div" className="text-red-500 text-xs mt-1" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Confirm Password</label>
                  <Field 
                    as={Input} 
                    type="password" 
                    name="confirmPassword" 
                    placeholder="••••••••" 
                  />
                  <ErrorMessage name="confirmPassword" component="div" className="text-red-500 text-xs mt-1" />
                </div>

                <Button 
                  type="submit" 
                  className="w-full mt-4"
                  disabled={isSubmitting || !(isValid && dirty)}
                >
                  {isSubmitting ? 'Creating account...' : 'Create Account'}
                </Button>
              </Form>
            )}
          </Formik>
        )}
      </motion.div>
    </div>
  );
};

export default Register;