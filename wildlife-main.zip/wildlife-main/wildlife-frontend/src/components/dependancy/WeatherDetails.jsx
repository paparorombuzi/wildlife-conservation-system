import React from 'react';
import { motion } from 'framer-motion';

const WeatherDetails = ({ data }) => {
  return (
    <div className="bg-white p-4 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">Weather Details</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {data.map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className="bg-gray-50 p-3 rounded-lg"
          >
            <p className="text-sm font-medium text-gray-600">{item.dt_txt}</p>
            <div className="flex items-center">
              <img
                src={`http://openweathermap.org/img/wn/${item.weather[0].icon}@2x.png`}
                alt={item.weather[0].description}
                className="w-12 h-12"
              />
              <p className="text-lg font-bold ml-2">{item.main.temp}°C</p>
            </div>
            <p className="text-sm">Feels like: {item.main.feels_like}°C</p>
            <p className="text-sm">Humidity: {item.main.humidity}%</p>
            <p className="text-sm">Pressure: {item.main.pressure} hPa</p>
            <p className="text-sm">Wind: {item.wind.speed} m/s</p>
            <p className="text-sm">Conditions: {item.weather[0].description}</p>
            <p className="text-sm">Visibility: {item.visibility / 1000} km</p>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default WeatherDetails;