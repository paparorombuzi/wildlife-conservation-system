import React from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// Custom location icon for plant markers (a location pin)
const locationIcon = L.icon({
  iconUrl: "https://cdn-icons-png.flaticon.com/512/684/684908.png", // Replace with your preferred location pin icon URL
  iconSize: [30, 30],
  iconAnchor: [15, 30],
  popupAnchor: [0, -30],
});

// Default icon for deforestation events
const deforestationIcon = L.icon({
  iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
});

const Map = ({ markers = [] }) => {
  // Debug log markers to verify data
  console.log("markers:", markers);

  return (
    <div className="bg-white p-1 rounded shadow mb-8">
      <MapContainer center={[0, 0]} zoom={2} 
       className="h-[100vh] w-full rounded-lg"
      style={{ height: "500px", width: "100%",filter: 'sepia(0.6)' }}>
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution="&copy; OpenStreetMap contributors"
        />
        {markers.map((marker, index) => (
          <Marker
            key={index}
            position={[marker.lat, marker.lon]}
            icon={marker.type === "plant" ? locationIcon : deforestationIcon}
          >
            <Popup>
              {marker.type === "plant" ? (
                <strong>{marker.name}</strong>
              ) : (
                <div>
                  <strong className="text-black">{marker.name}</strong>
                  <br />
                  {marker.location}
                  <br />
                  Status: {marker.status}
                </div>
              )}
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
};

export default Map;
