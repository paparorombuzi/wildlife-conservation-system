// DataTable.jsx
import React from "react";

const DataTable = ({ data }) => {
  return (
    <div className="bg-white p-4 rounded shadow mb-8 overflow-x-auto">
      <h2 className="text-xl font-semibold mb-4">Plant Data</h2>
      <table className="min-w-full text-left bg-white">
        <thead>
          <tr className="border-b">
            <th className="py-2 px-4">Name</th>
            <th className="py-2 px-4">Scientific Name</th>
            <th className="py-2 px-4">Status</th>
            <th className="py-2 px-4">Biodiversity Index</th>
            <th className="py-2 px-4">Location</th>
          </tr>
        </thead>
        <tbody>
          {data.map((plant, index) => (
            <tr key={index} className="border-b hover:bg-gray-50">
              <td className="py-2 px-4">{plant.name}</td>
              <td className="py-2 px-4">{plant.scientific_name}</td>
              <td className="py-2 px-4">{plant.status}</td>
              <td className="py-2 px-4">{plant.biodiversity_index}</td>
              <td className="py-2 px-4">{plant.location}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DataTable;
