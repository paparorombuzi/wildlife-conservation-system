// WeatherAlert.jsx
import React from 'react';

const WeatherAlert = ({ alertMessage }) => {
  return (
    <div className="bg-yellow-200 border-l-4 border-yellow-600 text-yellow-800 p-4 my-4">
      <p className="font-bold">Weather Alert</p>
      <p>{alertMessage}</p>
    </div>
  );
};

export default WeatherAlert;
