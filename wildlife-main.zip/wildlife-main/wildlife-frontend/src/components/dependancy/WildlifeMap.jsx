// WildlifeMap.jsx
import React from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

const WildlifeMap = ({ lat, lon, weatherData }) => {
  return (
    <div className=" w-full h-[100vh]">
      <MapContainer
        center={[lat, lon]}
        zoom={10}
        className="w-full h-full"
        style={{ filter: 'sepia(0.6)' }} // brownish, wildlife-inspired filter
      >
        <TileLayer 
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" 
          attribution="&copy; OpenStreetMap contributors"
        />
        {weatherData &&
          weatherData.map((weather, index) => (
            <Marker key={index} position={[weather.lat, weather.lon]}>
              <Popup>{weather.description}</Popup>
            </Marker>
          ))
        }
      </MapContainer>
      {/* A transparent overlay for a subtle spinning effect */}
      <div className=" inset-0 pointer-events-none animate-spin-slow" />
    </div>
  );
};

export default WildlifeMap;
