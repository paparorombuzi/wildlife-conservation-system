import React from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-3 rounded-lg shadow-md">
        <p className="font-semibold">{label}</p>
        <p>Temperature: {payload[0].value}°C</p>
        <p>Humidity: {payload[1].value}%</p>
        <p>Wind Speed: {payload[2].value} m/s</p>
        <p>Conditions: {payload[0].payload.weather[0].description}</p>
      </div>
    );
  }
  return null;
};

const WeatherForecastChart = ({ data }) => {
  return (
    <div className="w-full h-64">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <XAxis dataKey="dt_txt" />
          <YAxis yAxisId="left" domain={['auto', 'auto']} />
          <YAxis yAxisId="right" orientation="right" domain={['auto', 'auto']} />
          <Tooltip content={<CustomTooltip />} />
          <Legend />
          <Line yAxisId="left" type="monotone" dataKey="temp" stroke="#8B4513" strokeWidth={2} name="Temperature (°C)" />
          <Line yAxisId="right" type="monotone" dataKey="humidity" stroke="#82ca9d" strokeWidth={2} name="Humidity (%)" />
          <Line yAxisId="right" type="monotone" dataKey="wind.speed" stroke="#8884d8" strokeWidth={2} name="Wind Speed (m/s)" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default WeatherForecastChart;