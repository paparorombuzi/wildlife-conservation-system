// dataUtils.js

// Function to calculate KPIs for plant data
export const calculateKPIs = (data) => {
  if (!data || !Array.isArray(data)) {
    return { totalSpecies: 0, endangeredSpecies: 0, avgBiodiversityIndex: 0 };
  }
  const totalSpecies = data.length;
  const endangeredSpecies = data.filter((plant) => plant.status === "Endangered").length;
  const avgBiodiversityIndex =
    totalSpecies > 0
      ? data.reduce((sum, plant) => sum + plant.biodiversity_index, 0) / totalSpecies
      : 0;
  return { totalSpecies, endangeredSpecies, avgBiodiversityIndex };
};

// Function to generate trends data for plants
export const getTrends = (data) => {
  if (!data || !Array.isArray(data)) {
    return {
      labels: [],
      datasets: [
        {
          label: "Biodiversity Index",
          data: [],
          borderColor: "#4CAF50", // Greenish color
          fill: false,
        },
      ],
    };
  }

  // Use 'year' or 'date' if available, otherwise use plant name or index
  const labels = data.map((plant, index) => plant.year || plant.date || plant.name || index);
  const biodiversityData = data.map((plant) => plant.biodiversity_index);

  return {
    labels,
    datasets: [
      {
        label: "Biodiversity Index",
        data: biodiversityData,
        borderColor: "#4CAF50", // Greenish color
        fill: false,
      },
    ],
  };
};

// Function to generate distribution data for plants
export const getDistribution = (data) => {
  if (!data || !Array.isArray(data)) {
    return {
      labels: [], // Default empty labels
      datasets: [
        {
          label: "Plant Distribution",
          data: [], // Default empty data
          backgroundColor: ["#81C784", "#66BB6A", "#4CAF50", "#388E3C", "#1B5E20"], // Gradient greenish colors
        },
      ],
    };
  }

  const distribution = data.reduce((acc, plant) => {
    const type = plant.type || "Unknown"; // Adjust based on your data
    acc[type] = (acc[type] || 0) + 1;
    return acc;
  }, {});

  return {
    labels: Object.keys(distribution),
    datasets: [
      {
        label: "Plant Distribution",
        data: Object.values(distribution),
        backgroundColor: ["#81C784", "#66BB6A", "#4CAF50", "#388E3C", "#1B5E20"], // Gradient greenish colors
        borderWidth: 0, // Removes borders between segments
      },
    ],
  };
};

// Function to generate map markers
export const getMarkers = (plantData, deforestationData) => {
  const markers = [];

  // Add plant markers with type property
  if (plantData && Array.isArray(plantData)) {
    plantData.forEach((plant) => {
      if (plant.latitude && plant.longitude) {
        markers.push({
          lat: plant.latitude,
          lon: plant.longitude,
          popup: `Plant: ${plant.name}, Status: ${plant.status}`,
          type: "plant", // add type property for plant markers
          color: "#4CAF50", // Greenish color for plant markers
        });
      }
    });
  }

  // Add deforestation markers with type property
  if (deforestationData && Array.isArray(deforestationData)) {
    deforestationData.forEach((event) => {
      if (event.latitude && event.longitude) {
        markers.push({
          lat: event.latitude,
          lon: event.longitude,
          popup: `Deforestation Event: Brightness: ${event.bright_ti4}, FRP: ${event.frp}`,
          type: "deforestation",
          color: "#FF5722", // Orange color for deforestation markers
        });
      }
    });
  }

  return markers;
};