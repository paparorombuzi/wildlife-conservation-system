// Charts.jsx
import React from "react";
import { Line } from "react-chartjs-2";

const Charts = ({ trends }) => {
  return (
    <div className=" p-4 rounded shadow">

      {trends?.labels?.length > 0 ? (
        <Line data={trends} options={{ responsive: true }} />
      ) : (
        <p className="text-gray-500">No plant trends data available.</p>
      )}
    </div>
  );
};

export default Charts;
