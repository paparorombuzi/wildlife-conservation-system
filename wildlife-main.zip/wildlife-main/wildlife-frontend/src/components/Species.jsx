import React, { useEffect, useState } from "react";
import axios from "axios";
import { Bar, Line } from "react-chartjs-2";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { FaLeaf, FaSpinner, FaDownload, FaSearch } from "react-icons/fa";
import { motion } from "framer-motion";

// Custom marker icon
const customIcon = L.icon({
  iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
});

const Species = ({ isSidebarOpen }) => {
  const [speciesData, setSpeciesData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");

  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await axios.get("http://localhost:8000/api/species_data/");
      // Only update state if response.data is not empty
      if (response.data && response.data.length > 0) {
        setSpeciesData(response.data);
        setFilteredData(response.data);
        localStorage.setItem("speciesData", JSON.stringify(response.data));
      }
      setError(null);
    } catch (error) {
      console.error("Error fetching species data:", error);
      setError("Failed to fetch species data. Please try again later.");
    } finally {
      setLoading(false);
    }
  };
  
  useEffect(() => {
    const cachedData = localStorage.getItem("speciesData");
    if (cachedData) {
      setSpeciesData(JSON.parse(cachedData));
      setFilteredData(JSON.parse(cachedData));
      setLoading(false);
    }
    fetchData();
  }, []);

  // Filter species by search query
  useEffect(() => {
    const filtered = speciesData.filter((data) =>
      data.species.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setFilteredData(filtered);
  }, [searchQuery, speciesData]);

  // Chart data for population trends
  const populationTrendData = {
    labels: filteredData.map((data) => data.species),
    datasets: [
      {
        label: "Population Trend",
        data: filteredData.map((data) => {
          switch (data.population_trend) {
            case "increasing":
              return 1;
            case "decreasing":
              return -1;
            case "stable":
              return 0;
            default:
              return 0;
          }
        }),
        backgroundColor: filteredData.map((_, index) => {
          const colors = ["#8B4513", "#A0522D", "#D2691E", "#CD853F", "#F4A460"];
          return colors[index % colors.length]; // Cycle through colors
        }),
        borderColor: filteredData.map((_, index) => {
          const colors = ["#8B4513", "#A0522D", "#D2691E", "#CD853F", "#F4A460"];
          return colors[index % colors.length]; // Cycle through colors
        }),
        borderWidth: 1,
      },
    ],
  };

  // Chart data for predicted population change
  const predictedPopulationData = {
    labels: filteredData.map((data) => data.species),
    datasets: [
      {
        label: "Predicted Population Change",
        data: filteredData.map((data) => {
          const change = data.predicted_population_change;
          if (change.includes("+")) return parseFloat(change.replace("%", ""));
          if (change.includes("-")) return parseFloat(change.replace("%", ""));
          return 0;
        }),
        backgroundColor: filteredData.map((_, index) => {
          const colors = ["#8B4513", "#A0522D", "#D2691E", "#CD853F", "#F4A460"];
          return colors[index % colors.length]; // Cycle through colors
        }),
        borderColor: filteredData.map((_, index) => {
          const colors = ["#8B4513", "#A0522D", "#D2691E", "#CD853F", "#F4A460"];
          return colors[index % colors.length]; // Cycle through colors
        }),
        borderWidth: 2,
        fill: false,
      },
    ],
  };

  // Calculate map center based on valid coordinates
  const validCoordinates = filteredData.filter(
    (data) => data.latitude !== null && data.longitude !== null
  );
  const mapCenter =
    validCoordinates.length > 0
      ? [validCoordinates[0].latitude, validCoordinates[0].longitude]
      : [0, 0];

  // Download filtered data as CSV
  const downloadCSV = () => {
    const headers = [
      "Species",
      "Population Trend",
      "Habitat Range",
      "Threats",
      "Conservation Status",
      "Climate Impact",
      "Predicted Population Change",
    ];
    const csvContent =
      "data:text/csv;charset=utf-8," +
      headers.join(",") +
      "\n" +
      filteredData
        .map((data) =>
          [
            data.species,
            data.population_trend,
            data.habitat_range,
            data.threats,
            data.conservation_status,
            data.climate_impact,
            data.predicted_population_change,
          ].join(",")
        )
        .join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "species_data.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    // bg-[#f5f3ee] 
    <div className={`p-10 transition-all duration-500 ${isSidebarOpen ? "ml-48" : "ml-16"} bg-white font-sans min-h-screen`}>
      <motion.h1 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-4xl font-bold text-brown-900 text-center mb-8 flex items-center justify-center gap-3"
      >
        <FaLeaf className="text-brown-700" /> Species Population Dynamics
    </motion.h1>
      {loading ? (
        <div className="flex justify-center items-center">
          <div className="w-12 h-12 border-4 border-t-4 border-[#8B4513] border-t-transparent rounded-full animate-spin"></div>
        </div>
      ) : error ? (
        <p className="text-red-600 text-center">{error}</p>
      ) : (
        <>
          {/* Search and Download Section */}
          <div className="flex flex-col md:flex-row gap-4 justify-between items-center mb-6">
            <div className="relative w-full md:w-1/2">
              <input
                type="text"
                placeholder="Search species..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8B4513]"
              />
              <FaSearch className="absolute left-3 top-3 text-gray-500" />
            </div>
            <button
              onClick={downloadCSV}
              className="flex items-center gap-2 bg-[#8B4513] text-white px-4 py-2 rounded-lg hover:bg-[#A0522D] transition-colors"
            >
              <FaDownload /> Download as CSV
            </button>
          </div>

          {/* Species Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-3">
            {filteredData.map((data) => (
              <motion.div
                      initial={{ y: 50, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.2 }}
                key={data.species}
                className="bg-gray-50 p-3 rounded-lg"
              >
                <h2 className="text-xl font-bold text-[#4b3621] mb-3 flex items-center gap-2">
                  <FaLeaf className="text-[#8B4513]" /> {data.species}
                </h2>
                <p className="text-gray-700">
                  <strong>Population Trend:</strong> {data.population_trend}
                </p>
                <p className="text-gray-700">
                  <strong>Habitat Range:</strong> {data.habitat_range}
                </p>
                <p className="text-gray-700">
                  <strong>Threats:</strong> {data.threats}
                </p>
                <p className="text-gray-700">
                  <strong>Conservation Status:</strong> {data.conservation_status}
                </p>
                <p className="text-gray-700">
                  <strong>Climate Impact:</strong> {data.climate_impact}
                </p>
                <p className="text-gray-700">
                  <strong>Predicted Population Change:</strong> {data.predicted_population_change}
                </p>
                  </motion.div>
            ))}
          </div>

          {/* Charts in Columns */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10 mt-4 ">
            {/* Population Trend Chart */}
            <div className="rounded-lg  p-6 animate-fadeIn">
              <h2 className="text-xl font-bold text-[#4b3621] mb-4">Population Trends</h2>
              <div className="h-[32rem]">
                <Bar
                  data={populationTrendData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    indexAxis: window.innerWidth > 768 ? "x" : "y",
                  }}
                />
              </div>
            </div>

            {/* Predicted Population Change Chart */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8 }}
              className=" rounded-lg p-6 animate-fadeIn">
              <h2 className="text-xl font-bold text-brown-700  mb-4">Predicted Population Change</h2>
              <div className="h-[32rem]">
                <Line
                  data={predictedPopulationData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                  }}
                />
              </div>
              </motion.div>
          </div>

          {/* Geographic Distribution Map */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="p-1 mb-10"
      >
            <h2 className="text-xl font-bold text-brown-700 mb-4">Geographic Distribution</h2>
            <MapContainer center={mapCenter} zoom={3} className="h-[100vh] w-full rounded-lg"
             style={{ filter: 'sepia(0.6)' }} // brownish, wildlife-inspired filter 
            >
              <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
              {filteredData
                .filter((data) => data.latitude !== null && data.longitude !== null)
                .map((data) => (
                  <Marker key={data.species} position={[data.latitude, data.longitude]} icon={customIcon}>
                    <Popup>
                      <b>{data.species}</b>
                      <br />
                      Habitat: {data.habitat_range}
                      <br />
                      Threats: {data.threats}
                      <br />
                      Climate Impact: {data.climate_impact}
                    </Popup>
                  </Marker>
                ))}
            </MapContainer>
          </motion.div>
        </>
      )}
    </div>
  );
};

export default Species;