import { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { CreditCardIcon, ArrowPathIcon, ExclamationTriangleIcon } from '@heroicons/react/24/outline';

const TokenProgress = ({ used, total, isFallback }) => {
  const progress = Math.min(100, (used / total) * 100);
  return (
    <div>
      {isFallback && (
        <div className="flex items-center text-amber-300 mb-2 text-sm">
          <ExclamationTriangleIcon className="w-4 h-4 mr-1" />
          Showing approximate usage data
        </div>
      )}
      <div className="flex justify-between mb-2">
        <span>{used.toLocaleString()} / {total.toLocaleString()}</span>
        <span>{Math.round(progress)}%</span>
      </div>
      <div className="h-3 bg-white/20 rounded-full">
        <div 
          className="h-full bg-gradient-to-r from-amber-500 to-amber-300 rounded-full transition-all" 
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
};

export default function Api() {
  const [usageData, setUsageData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [totalTokens] = useState(600000);
  const [usingFallback, setUsingFallback] = useState(false);

  const fetchTokenUsage = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await fetch('http://localhost:8000/api/api_usage/');
      
      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.status !== 'success') {
        throw new Error(data.error || 'Invalid response from server');
      }

      setUsingFallback(data.source === 'fallback');
      
      setUsageData(prev => {
        const newEntry = {
          date: new Date().toLocaleTimeString(),
          tokens: data.remaining_tokens,
          usage: data.used_tokens,
          source: data.source
        };
        
        // Keep last 8 data points
        return [...prev.slice(-7), newEntry];
      });

    } catch (err) {
      console.error('Fetch Error:', err);
      setError(err.message);
      setUsingFallback(true);
      
      // Maintain last known good data or use fallback
      setUsageData(prev => prev.length > 0 ? prev : [{
        date: new Date().toLocaleTimeString(),
        tokens: totalTokens * 0.8,
        usage: totalTokens * 0.2,
        source: 'error_fallback'
      }]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTokenUsage();
    const interval = setInterval(fetchTokenUsage, 300000); // 5 minutes
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen p-8 text-white bg-gradient-to-br from-stone-900 via-slate-900 to-stone-800">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-6xl mx-auto">
        <div className="glass-card p-6">
          <h2 className="text-2xl mb-4 flex items-center gap-2">
            <CreditCardIcon className="w-6 h-6" />
            Token Usage
            <button 
              onClick={fetchTokenUsage} 
              disabled={loading}
              className="ml-auto"
              aria-label="Refresh"
            >
              <ArrowPathIcon className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </h2>
          
          {error && (
            <div className="text-rose-400 mb-2 flex items-center">
              <ExclamationTriangleIcon className="w-4 h-4 mr-1" />
              {error} - Using fallback data
            </div>
          )}

          {usageData.length > 0 ? (
            <TokenProgress 
              used={usageData[usageData.length - 1].usage} 
              total={totalTokens}
              isFallback={usingFallback}
            />
          ) : (
            <div className="h-8 bg-white/10 animate-pulse rounded" />
          )}
        </div>

        <div className="glass-card p-6 col-span-2 h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={usageData}>
              <XAxis 
                dataKey="date" 
                stroke="#94a3b8" 
                tick={{ fontSize: 12 }}
              />
              <YAxis 
                stroke="#94a3b8"
                domain={[0, totalTokens]}
              />
              <Tooltip 
                contentStyle={{
                  background: '#1e293b',
                  borderColor: '#334155',
                  borderRadius: '0.5rem',
                }}
                formatter={(value) => [value.toLocaleString(), 'Tokens']}
                labelFormatter={(label) => `Time: ${label}`}
              />
              <Line 
                type="monotone" 
                dataKey="tokens" 
                stroke="#f59e0b" 
                strokeWidth={2}
                dot={{ r: 4, fill: '#f59e0b' }}
                activeDot={{ r: 6, stroke: '#fff', strokeWidth: 2 }}
              />
            </LineChart>
          </ResponsiveContainer>
          {usingFallback && (
            <div className="text-amber-300 text-sm mt-2 flex items-center">
              <ExclamationTriangleIcon className="w-4 h-4 mr-1" />
              Displaying approximate usage data
            </div>
          )}
        </div>
      </div>
    </div>
  );
}