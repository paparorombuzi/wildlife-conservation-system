import React, { useEffect, useState, useMemo } from "react";
import axios from "axios";
import { Bar, Pie } from "react-chartjs-2";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import MarkerClusterGroup from "react-leaflet-markercluster";
import "leaflet/dist/leaflet.css";
import "leaflet.markercluster/dist/MarkerCluster.css";
import "leaflet.markercluster/dist/MarkerCluster.Default.css";
import { format, parseISO } from "date-fns";
import HeatmapLayer from "./HeatmapLayer";
import L from "leaflet";
// Import icons from react-icons
import { FaExclamationTriangle, FaCheckCircle, FaChartBar, FaMapMarkedAlt } from "react-icons/fa";

const customIcon = L.icon({
  iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
});

const WildlifeCrime = ({ isSidebarOpen }) => {
  const [wildlifeCrimeData, setWildlifeCrimeData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filter, setFilter] = useState({
    crimeType: "",
    species: "",
    startDate: "",
    endDate: "",
    search: "",
  });
  const [viewMode, setViewMode] = useState("markers");

  // Fetch data on mount with caching
  useEffect(() => {
    const fetchData = async () => {
      const cacheKey = "wildlifeCrimeData";
      const cachedData = localStorage.getItem(cacheKey);
      const cacheExpiry = localStorage.getItem(`${cacheKey}_expiry`);

      if (cachedData && cacheExpiry && Date.now() < parseInt(cacheExpiry)) {
        setWildlifeCrimeData(JSON.parse(cachedData));
        setLoading(false);
        return;
      }

      try {
        const response = await axios.get("http://127.0.0.1:8000/api/wildlife_crime/");
        const data = response.data;
        setWildlifeCrimeData(data);
        setError(null);
        localStorage.setItem(cacheKey, JSON.stringify(data));
        localStorage.setItem(`${cacheKey}_expiry`, Date.now() + 3600000);
      } catch (error) {
        console.error("Error fetching wildlife crime data:", error);
        setError("Failed to fetch wildlife crime data. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Filtering logic
  const filteredData = useMemo(() => {
    return wildlifeCrimeData.filter((item) => {
      const matchCrimeType = filter.crimeType ? item.crime_type === filter.crimeType : true;
      const matchSpecies = filter.species ? item.species === filter.species : true;
      const matchSearch = filter.search
        ? item.species.toLowerCase().includes(filter.search.toLowerCase()) ||
          item.crime_type.toLowerCase().includes(filter.search.toLowerCase())
        : true;
      const itemDate = new Date(item.date);
      const matchStartDate = filter.startDate ? itemDate >= new Date(filter.startDate) : true;
      const matchEndDate = filter.endDate ? itemDate <= new Date(filter.endDate) : true;
      return matchCrimeType && matchSpecies && matchSearch && matchStartDate && matchEndDate;
    });
  }, [wildlifeCrimeData, filter]);

  // KPI metrics & charts
  const totalIncidents = useMemo(() => filteredData.reduce((sum, item) => sum + item.incidents, 0), [filteredData]);
  const totalArrests = useMemo(() => filteredData.reduce((sum, item) => sum + item.arrests, 0), [filteredData]);
  const uniqueCrimeTypes = useMemo(() => new Set(filteredData.map((item) => item.crime_type)).size, [filteredData]);
  const uniqueSpecies = useMemo(() => new Set(filteredData.map((item) => item.species)).size, [filteredData]);

  const incidentsOverTime = useMemo(() => {
    const dataByDate = {};
    filteredData.forEach((item) => {
      const dateKey = format(parseISO(item.date), "yyyy-MM-dd");
      if (!dataByDate[dateKey]) {
        dataByDate[dateKey] = { incidents: 0, arrests: 0 };
      }
      dataByDate[dateKey].incidents += item.incidents;
      dataByDate[dateKey].arrests += item.arrests;
    });
    const labels = Object.keys(dataByDate).sort();
    const incidentsData = labels.map((label) => dataByDate[label].incidents);
    const arrestsData = labels.map((label) => dataByDate[label].arrests);
    return { labels, incidentsData, arrestsData };
  }, [filteredData]);

  const incidentsChartData = {
    labels: incidentsOverTime.labels,
    datasets: [
      {
        label: "Incidents",
        data: incidentsOverTime.incidentsData,
        backgroundColor: "#A0522D", // sienna
      },
      {
        label: "Arrests",
        data: incidentsOverTime.arrestsData,
        backgroundColor: "#CD853F", // peru
      },
    ],
  };

  const crimeTypeDistribution = useMemo(() => {
    const distribution = {};
    filteredData.forEach((item) => {
      distribution[item.crime_type] = (distribution[item.crime_type] || 0) + 1;
    });
  
    // Brownish colors array
    const brownishColors = ["#8B4513", "#A0522D", "#D2691E", "#CD853F", "#F4A460"];
  
    return {
      labels: Object.keys(distribution),
      datasets: [
        {
          data: Object.values(distribution),
          backgroundColor: Object.keys(distribution).map(
            (_, i) => brownishColors[i % brownishColors.length] // Cycle through the brownish colors
          ),
          borderWidth: 0, // Removes borders between segments
        },
      ],
    };
  }, [filteredData]);

  return (
    <div
      className={`transition-all duration-300 ${isSidebarOpen ? "ml-48" : "ml-16"} p-6`}
      style={{ fontFamily: "Arial, sans-serif"}}
    >
      <h1 className="text-3xl font-bold text-center mb-6 text-brown-700 animate-fadeIn">
        Wildlife Crime Dashboard
      </h1>
      {loading && (
        <div className="flex justify-center items-center">
          <div className="w-12 h-12 border-4 border-t-4 border-[#8B4513] border-t-transparent rounded-full animate-spin"></div>
        </div>
      )}
      {error && (
        <p className="text-center text-red-500 flex justify-center items-center gap-2">
          <FaExclamationTriangle /> {error}
        </p>
      )}
   <div className="flex flex-wrap justify-center gap-4 mb-6">
        <div
          className="bg-gradient-to-r from-brown-300 to-brown-500 p-4 shadow-lg rounded-lg w-60 cursor-pointer hover:scale-105 transition-transform"
          onClick={() => setFilter({ ...filter, search: "" })}
        >
          <h2 className="text-lg font-semibold mb-2 flex items-center gap-1 text-brown-800">
            <FaExclamationTriangle /> Total Incidents
          </h2>
          <p className="text-2xl text-brown-900">{totalIncidents}</p>
        </div>
        <div
          className="bg-gradient-to-r from-brown-300 to-brown-500 p-4 shadow-lg rounded-lg w-60 cursor-pointer hover:scale-105 transition-transform"
          onClick={() => setFilter({ ...filter, search: "" })}
        >
          <h2 className="text-lg font-semibold mb-2 flex items-center gap-1 text-brown-800">
            <FaCheckCircle /> Total Arrests
          </h2>
          <p className="text-2xl text-brown-900">{totalArrests}</p>
        </div>
        <div
          className="bg-gradient-to-r from-brown-300 to-brown-500 p-4 shadow-lg rounded-lg w-60 cursor-pointer hover:scale-105 transition-transform"
          onClick={() => setFilter({ ...filter, crimeType: "" })}
        >
          <h2 className="text-lg font-semibold mb-2 flex items-center gap-1 text-brown-800">
            <FaChartBar /> Crime Types
          </h2>
          <p className="text-2xl text-brown-900">{uniqueCrimeTypes}</p>
        </div>
        <div
          className="bg-gradient-to-r from-brown-300 to-brown-500 p-4 shadow-lg rounded-lg w-60 cursor-pointer hover:scale-105 transition-transform"
          onClick={() => setFilter({ ...filter, species: "" })}
        >
          <h2 className="text-lg font-semibold mb-2 flex items-center gap-1 text-brown-800">
            <FaMapMarkedAlt /> Species
          </h2>
          <p className="text-2xl text-brown-900">{uniqueSpecies}</p>
        </div>
      </div>

      {/* Advanced Filtering Controls */}
      <div className="flex flex-wrap gap-4 mb-6 justify-center">
        <div className="flex items-center gap-2">
          <FaChartBar className="text-brown-700" />
          <input
            type="text"
            placeholder="Search by species or crime type"
            className="border p-2 rounded focus:outline-none focus:ring-2 focus:ring-brown-400"
            value={filter.search}
            onChange={(e) => setFilter({ ...filter, search: e.target.value })}
          />
        </div>
        <div className="flex items-center gap-2">
          <FaChartBar className="text-brown-700" />
          <select
            className="border p-2 rounded focus:outline-none focus:ring-2 focus:ring-brown-400"
            value={filter.crimeType}
            onChange={(e) => setFilter({ ...filter, crimeType: e.target.value })}
          >
            <option value="">All Crime Types</option>
            {Array.from(new Set(wildlifeCrimeData.map((item) => item.crime_type))).map((type, index) => (
              <option key={index} value={type}>
                {type}
              </option>
            ))}
          </select>
        </div>
        <div className="flex items-center gap-2">
          <FaChartBar className="text-brown-700" />
          <select
            className="border p-2 rounded focus:outline-none focus:ring-2 focus:ring-brown-400"
            value={filter.species}
            onChange={(e) => setFilter({ ...filter, species: e.target.value })}
          >
            <option value="">All Species</option>
            {Array.from(new Set(wildlifeCrimeData.map((item) => item.species))).map((species, index) => (
              <option key={index} value={species}>
                {species}
              </option>
            ))}
          </select>
        </div>
        <input
          type="date"
          className="border p-2 rounded focus:outline-none focus:ring-2 focus:ring-brown-400"
          value={filter.startDate}
          onChange={(e) => setFilter({ ...filter, startDate: e.target.value })}
        />
        <input
          type="date"
          className="border p-2 rounded focus:outline-none focus:ring-2 focus:ring-brown-400"
          value={filter.endDate}
          onChange={(e) => setFilter({ ...filter, endDate: e.target.value })}
        />
      </div>

      {/* Summary & KPI Cards */}
     

      {/* Additional Charts */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
        <div className=" p-4  rounded-lg ">
          <h2 className="text-2xl font-bold text-brown-700 mb-4 flex items-center gap-2">Incidents & Arrests Over Time</h2>
          {filteredData.length > 0 ? (
            <Bar
              data={incidentsChartData}
              options={{
                responsive: true,
                plugins: {
                  title: { display: true, text: "Incidents vs Arrests Over Time" },
                },
                scales: { x: { stacked: true }, y: { stacked: true } },
              }}
            />
          ) : (
            <p className="text-gray-500">No data available</p>
          )}
        </div>
        <div className="p-4 max-w-xl">
          <h2 className="text-2xl font-bold text-brown-700 mb-4 flex items-center gap-2">Crime Type Distribution</h2>
          {filteredData.length > 0 ? (
            <Pie data={crimeTypeDistribution} />
          ) : (
            <p className="text-gray-500">No data available</p>
          )}
        </div>
      </div>

      {/* Map Toggle Buttons */}
      <div className="flex justify-center mb-4 gap-4 animate-fadeIn">
        <button
          className="px-4 py-2 bg-brown-500 text-white rounded hover:bg-brown-600 transition-colors"
          onClick={() => setViewMode("markers")}
        >
          Marker View
        </button>
        <button
          className="px-4 py-2 bg-brown-500 text-white rounded hover:bg-brown-600 transition-colors"
          onClick={() => setViewMode("heatmap")}
        >
          Heatmap View
        </button>
      </div>

      {/* Map for Wildlife Crime Locations */}
      <div className="bg-white p-4 shadow-lg rounded-lg mb-6 animate-fadeIn">
        <h2 className="text-lg font-semibold mb-2 text-brown-800">Wildlife Crime Locations</h2>
        <MapContainer center={[0, 0]} zoom={2} 
       className="h-[100vh] w-full rounded-lg"
       style={{ filter: 'sepia(0.6)' }} // brownish, wildlife-inspired filter 
       >
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution='&copy; OpenStreetMap contributors'
          />
          {viewMode === "markers" ? (
            <MarkerClusterGroup>
              {filteredData.map((item, index) => (
                <Marker key={index} position={[item.latitude, item.longitude]} icon={customIcon}>
                  <Popup>
                    <div>
                      <strong>Crime Type:</strong> {item.crime_type} <br />
                      <strong>Species:</strong> {item.species} <br />
                      <strong>Incidents:</strong> {item.incidents} <br />
                      <strong>Arrests:</strong> {item.arrests} <br />
                      <strong>Date:</strong> {item.date}
                    </div>
                  </Popup>
                </Marker>
              ))}
            </MarkerClusterGroup>
          ) : (
            <HeatmapLayer
              points={filteredData.map((item) => [item.latitude, item.longitude, item.incidents])}
              options={{
                radius: 40,
                blur: 10,
                max: Math.max(...filteredData.map((item) => item.incidents)) * 2.7,
                gradient: {
                  0.2: "blue",
                  0.4: "cyan",
                  0.6: "lime",
                  0.8: "yellow",
                  1.0: "red",
                },
              }}
            />
          )}
        </MapContainer>
      </div>

      {/* Interactive Data Table */}
      <div className="bg-white p-4 shadow-lg rounded-lg animate-fadeIn">
        <h2 className="text-lg font-semibold mb-2 text-brown-800">Wildlife Crime Data</h2>
        <table className="min-w-full bg-white">
          <thead>
            <tr>
              <th className="py-2 px-4 border-b">Crime Type</th>
              <th className="py-2 px-4 border-b">Species</th>
              <th className="py-2 px-4 border-b">Incidents</th>
              <th className="py-2 px-4 border-b">Arrests</th>
              <th className="py-2 px-4 border-b">Date</th>
            </tr>
          </thead>
          <tbody>
            {filteredData.map((item, index) => (
              <tr key={index} className="hover:bg-brown-100 transition-colors">
                <td className="py-2 px-4 border-b">{item.crime_type}</td>
                <td className="py-2 px-4 border-b">{item.species}</td>
                <td className="py-2 px-4 border-b">{item.incidents}</td>
                <td className="py-2 px-4 border-b">{item.arrests}</td>
                <td className="py-2 px-4 border-b">{item.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default WildlifeCrime;
