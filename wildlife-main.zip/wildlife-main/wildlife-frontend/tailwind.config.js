module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      animation: {
        'spin-vertical': 'spin-vertical 90s linear infinite', // Slow vertical rotation
      },
      keyframes: {
        'spin-vertical': {
          '0%': { transform: 'rotateX(0deg)' },
          '100%': { transform: 'rotateX(360deg)' }, // Spins top to bottom
        },
      },
      colors: {
        brown: {
          'deep-brown': '#2b1c0f',
          'deep-blue': '#0f3d5e',
          'accent-gold': '#f59e0b',
          50: '#fdf8f6',
          100: '#f2e8e5',
          200: '#eaddd7',
          300: '#e0cec7',
          400: '#d2bab0',
          500: '#bfa094',
          600: '#a18072',
          700: '#977669',
          800: '#846358',
          900: '#43302b',
        },
      },
    },
  },
  plugins: [],
}
